module.exports = function() {
	this.cacheable();

	return '';
};

module.exports.pitch = function() {
	this.cacheable();

	return '';
};
