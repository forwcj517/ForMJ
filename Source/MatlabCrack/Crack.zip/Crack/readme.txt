1. Copy content from dvd1.iso and dvd2.iso to same folder and run setup.exe
2. Enter serial 09806-07443-53955-64350-21751-41297 when provided
3. copy .dll to \MATLAB\R2017a\bin\win64\matlab_startup_plugins\lmgrimpl\
4. copy .lic to \MATLAB\R2017a\licenses\

Thanks to -Alex-