

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-primary" data-collapsed="0">
                
                <div class="panel-heading">
                    <div class="panel-title" >
                        <i class="entypo-plus-circled"></i>
                        <?php echo get_phrase('sync  agent and supplier tours'); ?>
                    </div>
                </div>
                
                <div class="panel-body">

                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <?php echo form_open('api/syncAll', array('class' => 'form-horizontal form-groups-bordered validate', 'enctype' => "multipart/form-data")); ?>                 
                            <div class="col-sm-offset-3 col-sm-5">
                                <button type="submit" class="btn btn-info"><?php echo get_phrase('Agent tour sync'); ?></button>
                            </div>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    
                    
                    <div class="col-md-4">
                         <div class="form-group">
                            <?php echo form_open('api/syncVegas', array('class' => 'form-horizontal form-groups-bordered validate', 'enctype' => "multipart/form-data")); ?>                 
                            <div class="col-sm-offset-3 col-sm-5">
                                <button type="submit" class="btn btn-info"><?php echo get_phrase('Vegas tours '); ?></button>
                            </div>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    
                    
                    <div class="col-md-4">
                         <div class="form-group">
                            <?php echo form_open('api/sync_agent', array('class' => 'form-horizontal form-groups-bordered validate', 'enctype' => "multipart/form-data")); ?>                 
                            <div class="col-sm-offset-3 col-sm-5">
                                <button type="submit" class="btn btn-info"><?php echo get_phrase('Thailand supplier tours'); ?></button>
                            </div>
                            <?php echo form_close(); ?>
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                    
                    
                   
                    
                    
                    
                    
                    
                   
                    
                    
                </div>
            </div>
        </div>
    </div>
