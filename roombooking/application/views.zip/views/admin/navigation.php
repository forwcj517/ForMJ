<div class="sidebar-menu">
    
    <header class="logo-env" >
        <!-- logo -->
        <div class="logo" style=""> 
            <a href="<?php echo site_url()."/admin"; ?>">
                <img src="<?php echo base_url('assets_extra/img/login.png'); ?>"  style="max-height:60px;"/>
            </a>
        </div>
        
        <!-- logo collapse icon -->
        <div class="sidebar-collapse" style="">
            <a href="#" class="sidebar-collapse-icon with-animation">
                <i class="entypo-menu"></i>
            </a>
        </div>

        <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
        <div class="sidebar-mobile-menu visible-xs">
            <a href="#" class="with-animation">
                <i class="entypo-menu"></i>
            </a>
        </div>
    </header>

    <div style="border-top:1px solid rgba(255, 255, 255, 0.9);"></div>	
    <ul id="main-menu" class="">
        <!-- add class "multiple-expanded" to allow multiple submenus to open -->
        <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->
        <li class="<?php if ($page_name == 'dashboard') echo 'active'; ?> ">
            <a href="<?php echo site_url("admin/dashboard"); ?>">
                <i class="entypo-home"></i>
                <span><?php echo get_phrase('dashboard'); ?></span>
            </a>
        </li>
        
        <li class="<?php if ($page_name == 'manager_customer') echo 'active'; ?> ">
            <a href="<?php echo site_url("admin/manager_customer"); ?>">
                <i class="entypo-user"></i>
                <span><?php echo get_phrase('Users'); ?></span>
            </a>
        </li>        
        <li class="<?php if ($page_name == 'reservations') echo 'active'; ?> ">
            <a href="<?php echo site_url("admin/reservations"); ?>">
                <i class="entypo-record"></i>
                <span><?php echo get_phrase('Orders'); ?></span>
            </a>
        </li>
        
        
        
        <?php if ($this->session->userdata('admin_login') == 1) { ?> 
        
            <li class="<?php if ($page_name == 'manager_city') echo 'active'; ?> ">
                <a href="<?php echo site_url("admin/manager_city"); ?>">
                    <i class="entypo-book"></i>
                    <span><?php echo get_phrase('City Management'); ?></span>
                </a>
            </li>
                        
            <li class="<?php if ($page_name == 'setting_contact' || $page_name == 'setting_file' || $page_name == 'email' ) echo 'opened active'; ?> ">
                <a href="#">
                    <i class="entypo-users"></i>
                    <span><?php echo get_phrase('configuration'); ?></span>
                </a>
                <ul>

                        <li class="<?php if ($page_name == 'setting_contact') echo 'active'; ?> ">
                            <a href="<?php echo site_url("admin/setting_contact"); ?>">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('Contact Us'); ?></span>
                            </a>
                        </li> 

                        <li class="<?php if ($page_name == 'setting_file') echo 'active'; ?> ">
                            <a href="<?php echo site_url("admin/setting_file"); ?>">
                                <span><i class="entypo-dot"></i> <?php echo get_phrase('Setting File'); ?></span>
                            </a>
                        </li>    
                        
<!--                        <li class="<?php if ($page_name == 'email') echo 'active'; ?> ">
                            <a href="<?php echo site_url("admin/email"); ?>">
                                <span>< i class="entypo-dot"></i>
                                <span><?php echo get_phrase('Email Format'); ?></span>
                            </a>
                        </li> -->

                </ul>
            </li>
            <li class="<?php if ($page_name == 'basic_faq') echo 'active'; ?> ">
                <a href="<?php echo site_url("admin/basic_faq"); ?>">
                    <i class="entypo-help"></i>
                    <span><?php echo get_phrase('FAQ'); ?></span>
                </a>
            </li>
            
            
           
            <li class="<?php if ($page_name == 'tour_sync') echo 'active'; ?> ">
               <a href="<?php echo site_url("admin/tour_sync"); ?>">
                   <i class="entypo-block"></i>
                   <span><?php echo get_phrase('Tour Sync'); ?></span>
               </a>
           </li> 
           
<!--    
                 
            <li class="<?php if ($page_name == 'basic_blog') echo 'active'; ?> ">
               <a href="<?php echo site_url("admin/basic_blog"); ?>">
                   <i class="entypo-block"></i>
                   <span><?php echo get_phrase('Blog'); ?></span>
               </a>
           </li>    -->
                
        
        <?php } ?>  
           
        
    </ul>

</div>