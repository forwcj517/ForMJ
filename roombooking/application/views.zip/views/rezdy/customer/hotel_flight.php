
<?php
//include ('../common/header.php') 
$this->load->view('rezdy/common/header');

?>
<script charset="utf-8" type="text/javascript" src="https://surf.surfyoutothemoon.co/iframe.js"></script>
<?php
$this->load->view('rezdy/common/footer');
?>