<?php 
//include ('../common/header.php') 
//$this->load->view('rezdy/common/header');
?>

<body>

    <div class="banner_contact">
        <img src="<?php echo base_url('assets_extra/img/contactus-banner.png');?>" class="img-responsive" style="width: 100%; height: 280px;" >
    </div>

    <div class="contact">
        <div class="container">
            <div class="row">
                
                <div class="col-md-8 col-sm-7">
                    <!-- Start Form -->
                                        
                    <div class="border_con">
                                            
                        <?php echo form_open('user/contact/', array('class' => ' form-groups-bordered validate'));?>
                        <h3>Keep in Touch</h3>
                        <div class="col-sm-12">
                            
                            <div class="row">                                
                                <div class="form-group col-sm-6">
                                    <h6>Full Name</h6>
                                    <input name="name" type="text" class="form-control" style="height:45px" placeholder="Enter your name....">
                                </div>
                                
                                <div class="form-group col-sm-6">
                                    <h6>Email Address</h6>
                                    <input name="email" type="email" class="form-control" style="height:45px" placeholder="Enter your email....">
                                </div>                                
                            </div>                            
                        </div>
                        
                        <div class="form-group col-sm-12">
                            <h6>Subject</h6>
                            <input type="text" name="title" class="form-control" style="height:45px" placeholder="Enter your subject....">
                        </div>

                        <div class="form-group col-sm-12">
                            <h6>Your Message</h6>
                            <textarea class="form-control" name="message" rows="7" placeholder="Enter your message...." required></textarea>
                        </div>
                        
                        <div class="form-group col-sm-3">                            
                            <button class="btn btn-warning waves-effect waves-light btn-block btn-lg margintop15" type="submit">Send Message</button>
                        </div>                        
                        <?php echo form_close();?>
                    </div>
                    
                   
                </div>
                                
                <div class="col-md-4 col-sm-5">
                    <div class="contact-detail continfo">
                        <div class="contact-sparator"></div>
                        <h3>Contact Us</h3>
                        <ul class="list-unstyled">
                            <li>
                                <h6><i class="fa fa-home fa-primary"></i> <span>Our location</span></h6>
                                <p><?php  echo $this->db->get_where('setting_contact', array('id'=>1))->row()->address;?>
                                </p>
                            </li>
                            
                            <li>
                                <h6><i class="fa fa-phone fa-primary"></i> <span>Call center</span></h6>
                                <p><?php  echo $this->db->get_where('setting_contact', array('id'=>1))->row()->phone;?>
                                </p>
                            </li>
                            
                            <li>
                                <h6><i class="fa fa-envelope fa-primary"></i> <span>Email address</span></h6>
                                <p><?php  echo $this->db->get_where('setting_contact', array('id'=>1))->row()->email;?>
                                </p>
                            </li>                            
<!--                            <li>
                                <h6><i class="fa fa-skype fa-primary"></i> <span>Skype</span></h6>
                                <p>abcd.123456789 
                                </p>
                            </li>-->

                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</body>







<!---Chat---->
<div class="text-center">
    <div class="row">
        <div class="round hollow">
            <a href="javascript:void(0)" id="addClass"><span class="glyphicon glyphicon-comment"></span> Support Chat </a>
        </div>

    </div>
</div>


<div class="popup-box chat-popup" id="qnimate">
    <div class="popup-head">
        <div class="popup-head-left pull-left">Chat with Support </div>
        <div class="popup-head-right pull-right">

            <button data-widget="remove" id="removeClass" class="chat-header-button pull-right" type="button"><i class="fa fa-times" aria-hidden="true"></i></button>
        </div>
    </div>
    <div class="popup-messages" style="height:308px">


        <div class="chat-form" id="chatfrom1" style=" display:block; ">
            <p> <b>Note:</b> To chat with our Support Team, please enter your information.To help us serve you better, please provide some information before we begin your chat.</p>
            <!--<form class="form-horizontal" method="post" action="#" onSubmit="">-->
                <!-- Text input-->
                <div class="form-group">
                    <div class="col-md-12">
                        <input placeholder="Your Email" value="" required class="form-control input-md" id="email" type="email">					
                    </div>
                </div>
                
                <div class="form-group">
                    <div class="col-md-12">			
                        <input placeholder="Your Phone Number" value="" required class="form-control input-md" id="password" type="text">					
                    </div>
                </div>
                <!-- Text input-->
                
                <!-- Text input-->
                <div class="form-group">
                    <div class="col-md-12 text-center">
                        <button  onclick="startChart()" type="submit" class="btn btn-success">Lets Start</button>					
                    </div>
                </div>
            <!--</form>-->
        </div>
        <div class="chat-hide" id="chatfrom2" style=" display:none; ">
            <div class="direct-chat-messages" style="height:308px">
                <!-- Message. Default to the left -->
                <div class="direct-chat-msg doted-border">
                    <div class="clearfix">
                        <span class="direct-chat-name pull-left">Support</span>
                        <span class="direct-chat-timestamp pull-right">3:05 PM</span>
                    </div>
                    <!-- /.direct-chat-info -->                      
                    <div class="direct-chat-text">
                        Hello, How can i help you today.Please write your query below..
                    </div>
                </div>
                               
                <div id="msg_container">
                    <div id="messages">
                                            
                        <!--
                        <?php foreach ($messages as $message): ?>
                                            
                            <div class="direct-chat-msg doted-border">
                                <div class="clearfix">
                                      <span class="direct-chat-name pull-left"><?php print $message['sender']; ?></span>
                                      <span class="direct-chat-timestamp pull-right">[<?php print $message['created_at']; ?>]</span>
                                </div>                                               
                                <div class="direct-chat-text">
                                     <?php print $message['message']; ?>							  
                                </div>
                            </div>

                            <div class="direct-chat-msg you-border">
                                <div class="clearfix">
                                      <span class="direct-chat-name pull-right"><?php print $message['sender']; ?></span>
                                      <span class="direct-chat-timestamp pull-left">[<?php print $message['created_at']; ?>]</span>
                                </div>
                                <div class="direct-chat-text1">
                                      <?php print $message['message']; ?>								  
                                </div>
                              </div>                    
                 
                             <?php endforeach; ?> -->               
                    </div>
                </div>
                
            </div>
            
            <div class="popup-messages-footer">                
               <?php echo form_open('messages/create', array('id' => 'new-message-form')) ?>
                
                <input hidden='true'  type="input" name="sender" id = 'sender' class="form-text" value="<?php echo $this->session->userdata('admin_id');?>"/>

				<input hidden='true' type="input" name="username" id = 'username' class="form-text" value="<?php echo $this->db->get_where('usertable',array('no'=>$this->session->userdata('admin_id')))->row()->name?>"/>

                <input hidden="true" type="input" name="receiver" id = 'receiver' class="form-text" value="<?php echo $this->session->userdata('admin_id');?>"/>
                
                <input type="input"  id= "input-message" name="msg" class="form-text"/>
                <input type="submit" name="submit" value="Send Message" class="form-submit"/>
              </form>
            </div>
<!--            <div class="popup-messages-footer">
                <textarea onkeyup="if (event.keyCode == 13) {
                            SendLivechatMsg();
                        }" style="border: 1px solid; height: 48px;" id="status_message" placeholder="Type your message..." rows="10" cols="40" name="message"></textarea>
            </div>-->
        </div>
    </div>
</div>


<script src="https://cdn.socket.io/socket.io-1.4.5.js"></script>
<script src="https://code.jquery.com/jquery-1.11.1.js"></script>


<!--<script>
      $(function () {
        var socket = io();
        $('form').submit(function(){
          socket.emit('chat message', $('#m').val());
          $('#m').val('');
          return false;
        });
        socket.on('chat message', function(message){            
            var msg =  "";
            msg = msg + '<div class="direct-chat-msg you-border">';
            msg = msg + '<div class="clearfix">';
            msg = msg + '<span class="direct-chat-name pull-right">99</span>';
            msg = msg + '<span class="direct-chat-timestamp pull-left">5:56 PM</span>';
            msg = msg + '</div>';
            msg = msg + '<div class="direct-chat-text1">';
            msg = msg + message;
            msg = msg + '</div></div>';
            var div = document.getElementById('LiveChatdiv');
            div.innerHTML = div.innerHTML + msg;                                                               
          //$('#messages').append($('<li>').text(msg));
          //window.scrollTo(0, document.body.scrollHeight);                   
        });
      });    192.169.141.31
</script>-->
<!--192.169.141.31-->
<script>
	 var socket = io.connect( "http://192.169.141.31:3005");
	var senderId;
	var username;
    $(document).ready(function () {   	
		 var senderElement = document.getElementById('sender');
 		  senderId = $('#sender').val();
 		  username = $('#username').val();

		if(senderId != null && senderId != "")
			socket.emit('join-room', {roomname: 'room:' + senderId, username: username});
        if("<?php echo $this->session->userdata('chat'); ?>" == 1){
            $("#chatfrom2").show();                  
            $("#chatfrom1").hide();
        }        
//         var $newMsgForm = $('#new-message-form');
//    
//        var $Container = $('#msg_container');
//        var $msgContainer = $('#messages');                    
//        $msgContainer.append($Container.children('div')).scrollTop($msgContainer[0].scrollHeight + 200);  
        
         $('.direct-chat-messages').animate({ scrollTop: $(document).height()}, 308); 
		
        $('form').submit(function(){            
            var msg = $("#input-message").val();
            if(msg != "" && msg != null){
                socket.emit('send-message', {roomname:'room:'+senderId, username:username, message: $('#input-message').val()});
                $('#input-message').val('');
		$('.direct-chat-messages').animate({ scrollTop: $(document).height()}, 308); 
            }          
            
          return false;
        });

        socket.on('onNewMessage', function(message){    
            var mydata =  "";
			
			var messageItem = message;//JSON.parse(message);
			if(messageItem.roomname != 'room:'+senderId) return; 
			console.log('username='+ message);
			mydata = mydata + '<div class="direct-chat-msg doted-border">';
			mydata = mydata + '<div class="clearfix">';
			mydata = mydata + '<span class="direct-chat-name pull-left">' + messageItem.username + '</span>';
			mydata = mydata + '<span class="direct-chat-timestamp pull-right">' + "" + '</span>';
			mydata = mydata + '</div>';
			mydata = mydata + '<div class="direct-chat-text">';
			mydata = mydata + messageItem.message;
			mydata = mydata + '</div>';
			mydata = mydata + '</div>';  

		
            var div = document.getElementById('messages');

            div.innerHTML = div.innerHTML + mydata;                                                               
          //$('#messages').append($('<li>').text(msg));
            //window.scrollTo(0, document.body.scrollHeight);                   
           $('.direct-chat-messages').animate({ scrollTop: $(document).height()}, 308); 
        });

    })    
    
    function startChart(check) { 
       
        var name=$("#password").val();    
        var email=$("#email").val();            
        jQuery.ajax({
            type: "POST",
            url: "<?php echo site_url('api/login'); ?>",
            dataType: 'json',
            data: {password: name, email: email},
            success: function (data) {
                if (data)
                {
                    // Show Entered Value                    
                    units = data.result;
                    $("#sender").val(units.no);

                    if(units != null){
                        
                        $("#chatfrom2").show();
                        $("#chatfrom1").hide();
                        senderId = units.no;
                        username = units.name;
                        socket.emit('join-room', {roomname: 'room:'+units.no, username:units.name});
                    }
 
                }
            }
        });
    }    

</script>


 <?php 
 //include ('../common/footer.php') 
 $this->load->view('rezdy/common/footer');
 ?>

