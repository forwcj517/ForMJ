<?php $this->load->view('rezdy/common/header'); ?>
<body>
    <div class="w1h1 medium">            
        <div style="text-align: center; vertical-align: central; margin-top: 30px;" >        
            <img src="<?php echo base_url('assets_extra/img/done.png');?>" class="img-responsive" style=" display:block; margin:auto;">       
            <h1><?php echo $message;?> </h1>
            <form action="<?php echo base_url('user/hotel_flight');?>">
                
                <div class="row">
                    <div class="form-group col-sm-4 confirm">
                    </div>
                    <div class="form-group col-sm-4 confirm">
                        <button class="btn btn-warning waves-effect waves-light btn-block btn-lg margintop15" type="submit">Book my hotel and flights</button>
                    </div>
                    <div class="form-group col-sm-4 confirm">
                    </div>
                </div>
                                
            </form>
            
        </div>
    </div>
</body>
