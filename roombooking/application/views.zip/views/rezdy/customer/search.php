<?php
//include ('../common/new-header.php') 
$this->load->view('rezdy/common/header');
?>

<script>

    var current = 1;
    $(document).ready(function () {
        $('.result').hide();
        $('#mydiv1').show();
  
        geolocate();
        current = 1;

    });


    function changelist(id)
    {
        $('.result').hide();
        $('#mydiv' + id).show();
        if (id == 1) {
            geolocate();
        }
        current = id;
        //concept(id);
    }



    function getTours() {
        var name = $('#activities').val();

        if (name != "" && name.length >= 2) {

            jQuery.ajax({
                type: "POST",
                url: "<?php echo site_url('api/getTourByName'); ?>",
                dataType: 'json',
                data: {name: name},
                success: function (data) {
                    if (data)
                    {
                        // Show Entered Value                           
                        locations = data.tours;
                        var toAppend = '';
                        $i = 0;
                        $.each(locations, function (i, o) {

                            if ($i % 4 == 0) {
                                toAppend = toAppend + '<div class="multi-slider-section">';
                            }
                            toAppend = toAppend + '<div class="col-sm-3">';
                            toAppend = toAppend + '<div id="homes-slider1" class="carousel slide" data-ride="carousel">';
                            toAppend = toAppend + '<div class="carousel-inner" role="listbox">';
                            toAppend = toAppend + '<div class="item active">';
                            var temp  = encodeURI(o.name.replace('&',':'));
                            toAppend = toAppend + '<a  href="<?php echo site_url('/') ?>' + encodeURI(temp.replace(' ','_')) + '">';
                            toAppend = toAppend + '<div class="tour-section">';
                            toAppend = toAppend + '<img src="' + o.image_url + '" style="width:100%;height: 300px;">';
                            toAppend = toAppend + '</div>';
                            toAppend = toAppend + '</a>';
                            toAppend = toAppend + '</div>';
                            toAppend = toAppend + '</div>';
                            toAppend = toAppend + '</div>';

                            toAppend = toAppend + '<div class="tour-dec">';
                            toAppend = toAppend + '<a  href="<?php echo site_url('/') ?>' + encodeURI(temp.replace(' ','_')) + '">';
                            toAppend = toAppend + '<h4><b>$' + o.price + '</b> ' + o.name + '</h4>';
                            //toAppend = toAppend + '<p>Entire home/apt - 2 beds</p>';
                            toAppend = toAppend + '<div class="fullwidth">';
                            toAppend = toAppend + '<div class="star-home">';

//                            if (o.rate_count == 5) {
//
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//
//                            } else if (o.rate_count == 4) {
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                            } else if (o.rate_count == 3) {
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                            } else if (o.rate_count == 2) {
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                            } else {
//                                toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                                toAppend = toAppend + '<i class="fa fa-star gray"></i>';
//                            }
//
//                            toAppend = toAppend + o.rate + ' reviews';


                            toAppend = toAppend + '</div>';
                            toAppend = toAppend + '</div>';
                            toAppend = toAppend + '</a>';
                            toAppend = toAppend + '</div>';
                            toAppend = toAppend + '</div>';
                            if (($i % 4 == 3) || locations.length == $i + 1) {
                                toAppend = toAppend + '</div>                            ';
                            }
                            $i = $i + 1;
                        });
                        //                                    if(locations.length > 0){
                        $("#activity").html(toAppend);
                        //                                    }
                    }
                }
            });
        }
    }

</script>


<script>
    // This example displays an address form, using the autocomplete feature
    // of the Google Places API to help users fill in the information.

    // This example requires the Places library. Include the libraries=places
    // parameter when you first load the API. For example:
    // <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

    function initAutocomplete() {
        // Create the autocomplete object, restricting the search to geographical
        // location types.
        autocomplete = new google.maps.places.Autocomplete(
                /** @type {!HTMLInputElement} */(document.getElementById('autocomplete')),
                {types: ['geocode']});

        // When the user selects an address from the dropdown, populate the address
        // fields in the form.
        //autocomplete.addListener('place_changed', fillInAddress);
        google.maps.event.addListener(autocomplete, 'place_changed', function () {
            var place = autocomplete.getPlace();
            console.log(place.address_components);
            //alert(place.geometry.location.lng())
            getNearBy(place.geometry.location.lat(), place.geometry.location.lng(), "#mydiv");
        });


//                        var uluru = {lat: -25.363, lng: 131.044};
//                        var map = new google.maps.Map(document.getElementById('map'), {
//                            zoom: 4,
//                            center: uluru
//                        });
//                        var contentString = '<div class="multi-slider-section" style="margin:0px;"><a  href="overview.php"><div class="tour-section"><img src="<?php echo base_url('assets_extra/img/homes.jpg'); ?>" style="width: 291px; height: 150px;" class="img-responsive"></div></a><div class="tour-dec"><a  href="overview.php"><h4><b>₹9,166</b> Secluded Intown Treehouse</h4><p>Entire home/apt - 2 beds</p><div class="fullwidth"><div class="star-home"><i class="fa fa-star yellow"></i><i class="fa fa-star yellow"></i><i class="fa fa-star yellow"></i><i class="fa fa-star yellow"></i><i class="fa fa-star yellow"></i>84 reviews</div></div></a></div></div>';
//
//                        var infowindow = new google.maps.InfoWindow({
//                            content: contentString
//                        });
//
//                        var marker = new google.maps.Marker({
//                            position: uluru,
//                            map: map,
//                            title: 'Uluru (Ayers Rock)',
//                            icon: '<?php echo base_url('assets_extra/img/marker.png'); ?>'
//                        });
//                        marker.addListener('click', function () {
//                            infowindow.open(map, marker);
//                        });

    }

    // Bias the autocomplete object to the user's geographical location,
    // as supplied by the browser's 'navigator.geolocation' object.
    function geolocate() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                var geolocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                };
                var circle = new google.maps.Circle({
                    center: geolocation,
                    radius: position.coords.accuracy
                });
                autocomplete.setBounds(circle.getBounds());
                if (current == 1) {
                    getNearBy(position.coords.latitude, position.coords.longitude, "#nearby");
                }
            });
        }
    }

    function getNearBy(lat, lon, mydiv) {
        jQuery.ajax({
            type: "POST",
            url: "<?php echo site_url('api/getNearBy'); ?>",
            dataType: 'json',
            data: {lat: lat, lon: lon},
            success: function (data) {
                if (data)
                {
                    // Show Entered Value                           
                    locations = data.tour;
                    var toAppend = '';
                    $i = 0;
                    $.each(locations, function (i, o) {

                        if ($i % 4 == 0) {
                            toAppend = toAppend + '<div class="multi-slider-section">';
                        }
                        toAppend = toAppend + '<div class="col-sm-3">';
                        toAppend = toAppend + '<div id="homes-slider1" class="carousel slide" data-ride="carousel">';
                        toAppend = toAppend + '<div class="carousel-inner" role="listbox">';
                        toAppend = toAppend + '<div class="item active">';
                        
                        var temp  = encodeURI(o.name.replace('&',':'));
                        toAppend = toAppend + '<a  href="<?php echo site_url('/') ?>' + encodeURI(temp.replace(' ','_')) + '">';
                        toAppend = toAppend + '<div class="tour-section">';
                        toAppend = toAppend + '<img src="' + o.image_url + '" style="width:100%;height: 300px;">';
                        toAppend = toAppend + '</div>';
                        toAppend = toAppend + '</a>';
                        toAppend = toAppend + '</div>';
                        toAppend = toAppend + '</div>';
                        toAppend = toAppend + '</div>';

                        toAppend = toAppend + '<div class="tour-dec">';
                        toAppend = toAppend + '<a  href="<?php echo site_url('/') ?>' + encodeURI(temp.replace(' ','_')) + '">';
                        toAppend = toAppend + '<h4><b>₹' + o.price + '</b> ' + o.name + '</h4>';
                        //toAppend = toAppend + '<p>Entire home/apt - 2 beds</p>';
                        toAppend = toAppend + '<div class="fullwidth">';
//                        
//                        toAppend = toAppend + '<div class="star-home">';
//                        toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                        toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                        toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                        toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                        toAppend = toAppend + '<i class="fa fa-star yellow"></i>';
//                        toAppend = toAppend + '84 reviews';                        
                       //toAppend = toAppend + '</div>';
                        toAppend = toAppend + '</div>';
                        toAppend = toAppend + '</a>';
                        toAppend = toAppend + '</div>';
                        toAppend = toAppend + '</div>';
                        if (($i % 4 == 3) || locations.length == $i + 1) {
                            toAppend = toAppend + '</div>                            ';
                        }
                        $i = $i + 1;
                    });
//                                    if(locations.length > 0){
                    $(mydiv).html(toAppend);
//                                    }
                }
            }
        });
    }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCndLJgwOIMsLuT_vzwPCUa9Qp3NZrq-8M &libraries=places&callback=initAutocomplete"
async defer></script>


<div class="listing">    
    <div class="container">
        <div class="col-sm-12">
            <div class="col-sm-2 yourlist"  style="height:100%;">
                <h4 class="listborder">Search</h4>
                <ul id="nav-tabs-wrapper" class="nav nav-tabs nav-pills nav-stacked well">
                    <li class="active"><a href="#vtab1" data-toggle="tab" onclick="return changelist(1);">Near By Search</a></li>
                    <li><a href="#vtab2" data-toggle="tab" onclick="return changelist(2);">Search by Location</a></li>
                    <li><a href="#vtab3" data-toggle="tab" onclick="return changelist(3);">Search by Activity </a></li>
                </ul>                        
                <!--<a class="btn btn-warning waves-effect waves-light" href="">Add New Listings</a>-->
            </div>

            <div class="col-sm-10">            
                <div class="left-homes result" id='mydiv1'>
                    <input type='hidden' id='current_page1' />
                    <input type='hidden' id='show_per_page1' />
                    <h1>Near By in 100mile from current location </h1>    
                    <div id="nearby">                                                        

                        <?php
                        $i = 0;
                        $query = $this->db->query("SELECT * FROM tour ORDER BY id DESC LIMIT 12");
                        $tours = $query->result_array();
                        foreach ($tours as $row1):
                            ?>                                                                                          
                            <?php if ($i % 4 == 0) { ?>
                                <div class="multi-slider-section">
                                <?php } ?>                    
                                <div class="col-sm-3">
                                    <div id="homes-slider1" class="carousel slide" data-ride="carousel">
                                        <div class="carousel-inner" role="listbox">
                                            <div class="item active">
                                                <a  href="<?php $temp = str_replace("&",":",$row1['name']); echo site_url('/'.urlencode(str_replace(" ","_",$temp)))?>">
                                                    <div class="tour-section">
                                                        <img src="<?php echo $row1['image_url']; ?>" style="width:100%;height: 220px;">
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tour-dec">                    
                                        <a  href="<?php $temp = str_replace("&",":",$row1['name']);  echo site_url('/'.urlencode(str_replace(" ","_",$temp)))?>">
                                            <h4><b>$<?php echo $row1['price']; ?></b> <?php
                                                if (strlen($row1['name']) > 15) {
                                                    echo $row1['name'] . substr(0, 14);
                                                } else {
                                                    echo $row1['name'];
                                                }
                                                ?></h4>

<!--                                            <div class="fullwidth">
                                                <div class="star-home">

                                                    <?php if ($row1['rate'] == 5) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                    <?php } else if ($row1['rate'] == 4) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } else if ($row1['rate'] == 3) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } else if ($row1['rate'] == 2) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } else { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } ?>                                                                             
                                                    <?php echo $row1['rate_count']; ?> reviews
                                                </div>
                                            </div>-->
                                        </a>
                                    </div>
                                </div> 
                                <?php if (($i % 4 == 3 ) || sizeof($tours) == $i + 1) { ?>
                                </div>                            
                            <?php } ?>
                            <?php
                            $i++;
                        endforeach;
                        ?>
                    </div>
                </div>   



                <div class="left-homes result" id='mydiv2'>                                      
                    <h1>Near By in 100mile from &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class=" input-lg" placeholder="Anywhere" id="autocomplete" onFocus="geolocate()"></h1>
                    <div id="mydiv">

                        <?php
                        $i = 0;
                        $query = $this->db->query("SELECT * FROM tour ORDER BY id DESC LIMIT 12");
                        $tours = $query->result_array();
                        foreach ($tours as $row1):
                            ?>                                                                                          
                            <?php if ($i % 4 == 0) { ?>
                                <div class="multi-slider-section">
                                <?php } ?>                    
                                <div class="col-sm-3">
                                    <div id="homes-slider1" class="carousel slide" data-ride="carousel">
                                        <div class="carousel-inner" role="listbox">
                                            <div class="item active">
                                                <a  href="<?php $temp = str_replace("&",":",$row1['name']); echo site_url('/'.urlencode(str_replace(" ","_",$temp)))?>">
                                                    <div class="tour-section">
                                                        <img src="<?php echo $row1['image_url']; ?>" style="width:100%;height: 250px;">
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tour-dec">                    
                                        <a  href="<?php $temp = str_replace("&",":",$row1['name']); echo site_url('/'.urlencode(str_replace(" ","_",$temp)))?>">
                                            <h4><b>$<?php echo $row1['price']; ?></b> <?php
                                                if (strlen($row1['name']) > 15) {
                                                    echo $row1['name'] . substr(0, 14);
                                                } else {
                                                    echo $row1['name'];
                                                }
                                                ?></h4>

<!--                                            <div class="fullwidth">
                                                <div class="star-home">
                                                    <?php if ($row1['rate'] == 5) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                    <?php } else if ($row1['rate'] == 4) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } else if ($row1['rate'] == 3) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } else if ($row1['rate'] == 2) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } else { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } ?>                                                                             
                                                    <?php echo $row1['rate_count']; ?> reviews
                                                </div>
                                            </div>-->
                                        </a>
                                    </div>
                                </div> 
                                <?php if (($i % 4 == 3 ) || sizeof($tours) == $i + 1) { ?>
                                </div>                            
                            <?php } ?>
                            <?php
                            $i++;
                        endforeach;
                        ?>

                    </div>


                </div>  



                <div class="left-homes result" id='mydiv3'>
                    <input type='hidden' id='current_page3' />
                    <input type='hidden' id='show_per_page3' />                    
                    <h1>Tour Name &nbsp;&nbsp;&nbsp;&nbsp;<input type="text" class=" input-lg" placeholder="Activities" id="activities" ><button onclick="getTours()" class="btn btn-warning waves-effect waves-light" type="submit" style="margin-left:5px;">Search</button></h1>

                    <div id="activity">                                 
                        <?php
                        $i = 0;
                        $query = $this->db->query("SELECT * FROM tour ORDER BY id DESC LIMIT 12");
                        $tours = $query->result_array();
                        foreach ($tours as $row1):
                            ?>                                                                                          
                            <?php if ($i % 4 == 0) { ?>
                                <div class="multi-slider-section">
                                <?php } ?>                    
                                <div class="col-sm-3">
                                    <div id="homes-slider1" class="carousel slide" data-ride="carousel">
                                        <div class="carousel-inner" role="listbox">
                                            <div class="item active">
                                                <a  href="<?php $temp = str_replace("&",":",$row1['name']);  echo site_url('/'.urlencode(str_replace(" ","_",$temp)))?>">
                                                    <div class="tour-section">
                                                        <img src="<?php echo $row1['image_url']; ?>" style="width:100%;height: 250px;">
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>

                                    
                                    <div class="tour-dec">
                                        <a  href="<?php $temp = str_replace("&",":",$row1['name']);  echo site_url('/'.urlencode(str_replace(" ","_",$temp)))?>">
                                            <h4><b>$<?php echo $row1['price']; ?></b> <?php
                                                if (strlen($row1['name']) > 15) {
                                                    echo $row1['name'] . substr(0, 14);
                                                } else {
                                                    echo $row1['name'];
                                                }
                                                ?></h4>

<!--                                            <div class="fullwidth">
                                                <div class="star-home">
                                                    <?php if ($row1['rate'] == 5) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                    <?php } else if ($row1['rate'] == 4) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } else if ($row1['rate'] == 3) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } else if ($row1['rate'] == 2) { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } else { ?>
                                                        <i class="fa fa-star yellow"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                        <i class="fa fa-star gray"></i>
                                                    <?php } ?>                                                                             
                                                    <?php echo $row1['rate_count']; ?> reviews
                                                </div>
                                            </div>-->
                                        </a>
                                    </div>
                                </div> 
                                <?php if (($i % 4 == 3 ) || sizeof($tours) == $i + 1) { ?>
                                </div>                            
                            <?php } ?>
                            <?php
                            $i++;
                        endforeach;
                        ?>
                    </div>


                </div>  

            </div>

        </div>
    </div>
</div>


<script>
    $(document).ready(function () {
        $('.multi-slider-section .carousel').carousel({
            pause: true,
            interval: false,
        });
    });
</script>


<style>
    /* Always set the map height explicitly to define the size of the div
     * element that contains the map. */
    #map {
        height: 100%;
    }
    /* Optional: Makes the sample page fill the window. */
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
    }
</style>


