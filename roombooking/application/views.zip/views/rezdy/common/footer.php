
<!-- footer-->
<!-- Start of surfyoutothemoon Zendesk Widget script -->
<script>/*<![CDATA[*/window.zEmbed||function(e,t){var n,o,d,i,s,a=[],r=document.createElement("iframe");window.zEmbed=function(){a.push(arguments)},window.zE=window.zE||window.zEmbed,r.src="javascript:false",r.title="",r.role="presentation",(r.frameElement||r).style.cssText="display: none",d=document.getElementsByTagName("script"),d=d[d.length-1],d.parentNode.insertBefore(r,d),i=r.contentWindow,s=i.document;try{o=s}catch(e){n=document.domain,r.src='javascript:var d=document.open();d.domain="'+n+'";void(0);',o=s}o.open()._l=function(){var e=this.createElement("script");n&&(this.domain=n),e.id="js-iframe-async",e.src="https://assets.zendesk.com/embeddable_framework/main.js",this.t=+new Date,this.zendeskHost="surfyoutothemoon.zendesk.com",this.zEQueue=a,this.body.appendChild(e)},o.write('<body onload="document._l();">'),o.close()}();
/*]]>*/</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!-- End of surfyoutothemoon Zendesk Widget script -->
<div class="footer">
	<div class="container">
    	<div class="row">
        	<div class="col-md-2 col-sm-6">
                    <p><img src="<?php echo base_url('assets_extra/img/logo.png');?>" style="width: 50px;height: 50px;"></p>
            </div>
            <div class="col-md-3 col-sm-6" style="padding-top: 25px;">
                <a href="https://itunes.apple.com/us/app/surf-you-to-the-moon/id1178850206?mt=8"><img src="https://www.surfyoutothemoon.com/wp-content/uploads/apple-app-store-badge.svg" alt="Download The Surf You To The Moon Mobile App On The Apple App Store" class="aligncenter size-full wp-image-5157" style="margin-left: 10px;"></a><br>
                <a href="https://play.google.com/store/apps/details?id=com.sjin.surf&amp;pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1"><img alt="Get it on Google Play" src="https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png" style="width:155px;height:63px" class="aligncenter"></a>
            </div>
        	<div class="col-md-2 foot-menu col-sm-6">
            	<h2>More Links</h2>
                <p><a href="<?php echo base_url('index.php/user/privacy_policy');?>">Privacy Policy</a></p>
                <p><a href="<?php echo base_url('index.php/user/terms');?>">Terms and Condition</a></p>
                <p><a href="<?php echo base_url('index.php/user/faq');?>">Faq</a></p>
            </div>
        	<div class="col-md-2 social col-sm-6">
            	<h2>Social</h2>
                
                <a href="https://www.facebook.com/travelyoutothemoon" target="_blank" class="btn-floating btn-large waves-effect waves-light red"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                <a href="https://www.instagram.com/travelyoutothemoon" target="_blank" class="btn-floating btn-large waves-effect waves-light red"><i class="fa fa-instagram" aria-hidden="true"></i></a>
            </div>
        	<div class="col-md-3 foot-cont col-sm-6">
            	<h2>Contact Us</h2>
                <p><?php  echo $this->db->get_where('setting_contact', array('id'=>1))->row()->address;?></p>	
                <p><?php  echo $this->db->get_where('setting_contact', array('id'=>1))->row()->email;?></p>	
                <p><?php  echo $this->db->get_where('setting_contact', array('id'=>1))->row()->phone;?></p>	
            </div>
        </div>
    </div>
</div>
<!-- footer-->
<!-- copyright-->
<!--<div class="copyright">
	<div class="container">
    &copy; Copyright 2017 Web Widers Software Solutions. All Rights Reserved.
    </div>
</div>-->

<!-- copyright-->
</div>







<!--addroll-->

<script type="text/javascript">
    adroll_adv_id = "PS5HO6U5LZEBJMUCCF6DIX";
    adroll_pix_id = "YE4DQNSVDJEMNOMBSY6WC7";
    /* OPTIONAL: provide email to improve user identification */
    /* adroll_email = "username@example.com"; */
    (function () {
        var _onload = zfunction(){
            if (document.readyState && !/loaded|complete/.test(document.readyState)){setTimeout(_onload, 10);return}
            if (!window.__adroll_loaded){__adroll_loaded=true;setTimeout(_onload, 50);return}
            var scr = document.createElement("script");
            var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com");
            scr.setAttribute('async', 'true');
            scr.type = "text/javascript";
            scr.src = host + "/j/roundtrip.js";
            ((document.getElementsByTagName('head') || [null])[0] ||
                document.getElementsByTagName('script')[0].parentNode).appendChild(scr);
        };
        if (window.addEventListener) {window.addEventListener('load', _onload, false);}
        else {window.attachEvent('onload', _onload)}
    }());
</script>



</body>
</html>
