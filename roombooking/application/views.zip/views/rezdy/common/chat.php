
<!---Chat---->
<div class="text-center">
    <div class="row">
        <div class="round hollow">
            <a href="javascript:void(0)" id="addClass"><span class="glyphicon glyphicon-comment"></span> Support Chat </a>
        </div>

    </div>
</div>


<div class="popup-box chat-popup" id="qnimate">
    <div class="popup-head">
        <div class="popup-head-left pull-left">Chat with Support </div>
        <div class="popup-head-right pull-right">

            <button data-widget="remove" id="removeClass" class="chat-header-button pull-right" type="button"><i class="fa fa-times" aria-hidden="true"></i></button>
        </div>
    </div>
    <div class="popup-messages" style="height:308px">


        <div class="chat-form" id="chatfrom1" style=" display:block; ">
            <p> <b>Note:</b> To chat with our Support Team, please enter your information.To help us serve you better, please provide some information before we begin your chat.</p>

            <form class="form-horizontal" method="post" action="#" onSubmit="return leststarchat();">
                <!-- Text input-->
                <div class="form-group">
                    <div class="col-md-12">			
                        <input placeholder="Your Name" value=" " required class="form-control input-md" id="name" type="text">					
                    </div>
                </div>
                <!-- Text input-->
                <div class="form-group">
                    <div class="col-md-12">
                        <input placeholder="Your Email" value="" required class="form-control input-md" id="email" type="email">					
                    </div>
                </div>
                <!-- Text input-->
                <div class="form-group">
                    <div class="col-md-12 text-center">
                        <button type="submit" class="btn btn-success">Lets Start</button>					
                    </div>
                </div>
            </form>
        </div>
        <div class="chat-hide" id="chatfrom2" style=" display:none; ">
            <div class="direct-chat-messages" style="height:308px">
                <!-- Message. Default to the left -->
                <div class="direct-chat-msg doted-border">
                    <div class="clearfix">
                        <span class="direct-chat-name pull-left">Support</span>
                        <span class="direct-chat-timestamp pull-right">3:05 PM</span>
                    </div>
                    <!-- /.direct-chat-info -->                      
                    <div class="direct-chat-text">
                        Hello, How can i help you today.Please write your query below..
                    </div>
                </div>
                <!-- /.direct-chat-msg -->
                <div id="LiveChatdiv">

                    <!-- Message. Default to the left -->
                    <div class="direct-chat-msg you-border">
                        <div class="clearfix">
                            <span class="direct-chat-name pull-right">99</span>
                            <span class="direct-chat-timestamp pull-left">5:56 PM</span>
                        </div>
                        <!-- /.direct-chat-info -->

                        <div class="direct-chat-text1">
                            hiiiii								  </div>
                    </div>
                    <!-- /.direct-chat-msg -->

                    <!-- Message. Default to the left -->
                    <div class="direct-chat-msg doted-border">
                        <div class="clearfix">
                            <span class="direct-chat-name pull-left">Support</span>
                            <span class="direct-chat-timestamp pull-right">5:56 PM</span>
                        </div>
                        <!-- /.direct-chat-info -->                      
                        <div class="direct-chat-text">
                            ya kya?								  </div>
                    </div>
                    <!-- /.direct-chat-msg -->
                    <!-- Message. Default to the left -->
                    <div class="direct-chat-msg doted-border">
                        <div class="clearfix">
                            <span class="direct-chat-name pull-left">Support</span>
                            <span class="direct-chat-timestamp pull-right">6:00 PM</span>
                        </div>
                        <!-- /.direct-chat-info -->                      
                        <div class="direct-chat-text">
                            ??								  </div>
                    </div>
                    <!-- /.direct-chat-msg -->

                    <!-- Message. Default to the left -->
                    <div class="direct-chat-msg you-border">
                        <div class="clearfix">
                            <span class="direct-chat-name pull-right">101</span>
                            <span class="direct-chat-timestamp pull-left">6:34 AM</span>
                        </div>
                        <!-- /.direct-chat-info -->

                        <div class="direct-chat-text1">
                            Salam%20nec%C9%99siniz%20								  </div>
                    </div>
                    <!-- /.direct-chat-msg -->


                    <!-- Message. Default to the left -->
                    <div class="direct-chat-msg you-border">
                        <div class="clearfix">
                            <span class="direct-chat-name pull-right">101</span>
                            <span class="direct-chat-timestamp pull-left">6:34 AM</span>
                        </div>
                        <!-- /.direct-chat-info -->

                        <div class="direct-chat-text1">
                            Tan%C4%B1%C5%9F%20olmaq.%20Olar%3F%20								  </div>
                    </div>
                    <!-- /.direct-chat-msg -->


                    <!-- Message. Default to the left -->
                    <div class="direct-chat-msg you-border">
                        <div class="clearfix">
                            <span class="direct-chat-name pull-right">101</span>
                            <span class="direct-chat-timestamp pull-left">6:34 AM</span>
                        </div>
                        <!-- /.direct-chat-info -->

                        <div class="direct-chat-text1">
                            %C6%8F%C3%B6%C4%9F%C5%9F%C3%A7%C4%B1dkfk								  </div>
                    </div>
                    <!-- /.direct-chat-msg -->


                    <!-- Message. Default to the left -->
                    <div class="direct-chat-msg you-border">
                        <div class="clearfix">
                            <span class="direct-chat-name pull-right">101</span>
                            <span class="direct-chat-timestamp pull-left">6:34 AM</span>
                        </div>
                        <!-- /.direct-chat-info -->

                        <div class="direct-chat-text1">
                            %D0%9E%D0%B0%D0%B4%D1%8B%D1%82%D1%81%D1%82%D0%BB%D0%B4%D0%BF%D1%8B								  </div>
                    </div>
                    <!-- /.direct-chat-msg -->


                    <!-- Message. Default to the left -->
                    <div class="direct-chat-msg you-border">
                        <div class="clearfix">
                            <span class="direct-chat-name pull-right">101</span>
                            <span class="direct-chat-timestamp pull-left">6:34 AM</span>
                        </div>
                        <!-- /.direct-chat-info -->

                        <div class="direct-chat-text1">
                            %F0%9F%98%84%20								  </div>
                    </div>
                    <!-- /.direct-chat-msg -->

                </div>
                <!-- /.direct-chat-msg -->
            </div>


            <div class="popup-messages-footer">
                <textarea onkeyup="if (event.keyCode == 13) {
                            SendLivechatMsg();
                        }" style="border: 1px solid; height: 48px;" id="status_message" placeholder="Type your message..." rows="10" cols="40" name="message"></textarea>

            </div>
        </div>
    </div>
</div>