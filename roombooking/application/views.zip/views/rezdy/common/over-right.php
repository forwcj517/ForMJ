
<?php 
$data = $this->db->get_where('tour', array('id'=>$id))->row();
$priceOptions = $this->db->get_where('priceoptions', array('productCode'=>$data->product_code))->result_array();
?>

<div class="over-right">
    <img src="<?php echo $data->image_url;?>" class="img-responsive" style="width: 100%; height:220px; position: relative; display: block;margin-left: auto; margin-right: auto;" >
    <h1><i class="fa fa-bolt"></i> <?php echo "$".$data->price; ?> <small></small></h1>
    <div class="over-right-body">
        
        <?php echo form_open('user/payment/', array('class' => 'form-horizontal form-groups-bordered validate'));?>                                                                
        
        <div class="row nomargin">
            <div class="col-sm-12 nopadding">
                <p class="nomargin"> Date </p>
                <input type="text" class="form-control" id="datePicker" name="date" required>
            </div>            
        </div>
                
        <div class="row nomargin" >
            <p class="nomargin">Time</p>    
            <div class="col-sm-12 nopadding">
                <select id="time" name="time" class="form-control time" required data-validate="required" data-message-required="<?php echo get_phrase('value_required'); ?>" >											                                
                </select>
            </div>
        </div>
                
        <div hidden="true">
            <input type="text" id="startDate" name="startDate" value="">
            <input type="text" id="endDate" name="endDate" value="">
            <input type="text" id="startDateShow" name="startDateShow" value="">
            <input type="text" id="endDateShow" name="endDateShow" value="">
        </div>
                        
        <?php           
            foreach ($priceOptions as $row1):
                ?>        
                <div class="row nomargin margintop10">
                    <div class="col-sm-12 nopadding">
                        <p class="nomargin"> <?php if($row1['label'] == "Quantity"){ echo "Select Tickets"; }else{ echo $row1['label']."(".$row1['price'].")";  };   ?> </p>
                        <input class="form-control guest" id="<?php echo $row1['label'];?>" type="number" min="0" name="<?php echo $row1['label'];?>" onkeyup="this.value = minmax(this.value, 1, 100)" />
                    </div>
                </div>
        <?php endforeach; ?>
                
        <div class="row nomargin margintop10">
            <div class="col-sm-12 nopadding">
                <p class="nomargin"> Promo Code</p>
                <input class="form-control" type="text" id="coupon" name="coupon" placeholder="optional" />
            </div>	
        </div>
                            
        <div class="row nomargin margintop10" hidden="true">
            <div class="col-sm-12 nopadding">
                <p class="nomargin"> Guests</p>
                <input class="form-control" type="text" name="tid" value="<?php echo $id; ?>" />
            </div>	
        </div>
        
        
        <?php if($data->auto_confirm == 1) {?>
            <button class="btn btn-warning waves-effect waves-light btn-block btn-lg margintop15" type="submit">Book</button>
        <?php } else { ?>
            <button class="btn btn-warning waves-effect waves-light btn-block btn-lg margintop15" type="submit">Book Now</button>
        <?php } ?>       
        <?php echo form_close();?>
        
        <p class="text-center"><small>You won't be charged yet</small></p>
        <hr>
        <div class="row">
            <div class="col-sm-9">
<!--                <h4 style="margin-bottom:0px;">This is a rare find.</h4>
                <p>Bruce's place is usually booked.</p>-->
            </div>
           
        </div>						
    </div>					
</div>	

<!--
<div class="over-right">
    <div class="over-right-body">
        <a href="" class="btn btn-default btn-block"><i class="fa fa-heart-o"></i> Save to Wish List</a>
        <br>
        <p class="text-center"><small>832 travelers saved this place</small></p>

        <p class="right-social">
            <a href=""><i class="fa fa-facebook" aria-hidden="true"></i></a>
            <a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
            <a href=""><i class="fa fa-envelope" aria-hidden="true"></i></a>
        </p>
    </div> 
</div>-->
<div class="ri-ov-bo">
    <p><a href=""><i class="fa fa-flag-o"></i> Save this tour</a></p>
</div>

<script>
    $(document).ready(function () {                
        var nowDate = new Date();
        var today = new Date(nowDate.getFullYear(), nowDate.getMonth(), nowDate.getDate(), 0, 0, 0, 0);
        //format: 'yyyy-mm-dd',
        $('#datePicker').datepicker({
                    format: 'yyyy-mm-dd',
                    startDate: today           
        });      
        
        $('#datePicker').datepicker()
            .on("input change", function (e) {                
            //alert(e.target.value);
            pickDate = e.target.value;
            if(pickDate != ""){
                clickDate(pickDate);
                $('#datePicker').datepicker("hide");
            }
            
        });
        
        $(".guest" ).change(function() {
          var bla = $('#guest').val();            
          var time_id = $('select[name=time]').val()
          
          $.each(sessions,function(i,o){                 
                if(time_id == o.id){
                    maxCount = o.seatsAvailable;
                }                
          });
                    
          if(bla > maxCount){
              alert("Max Count " + maxCount);
          }
          if(bla < 0){
              alert("Input Correct Number");
          }
        });
        
        $('.time').on('change', function (e) {            
            var optionSelected = $("option:selected", this);
            var valueSelected = this.value;                        
            var time_id = $('select[name=time]').val()          
            $.each(sessions,function(i,o){                 
                  if(time_id == o.id){
                      
                      startTimeLocal = o.startTime;
                      endTimeLocal = o.endTime;
                      
                      start = o.startTimeLocal.split(" ");
                      end = o.endTimeLocal.split(" ");
                                             
                      document.getElementById('startDate').value = o.startTime ;//start[1];
                      document.getElementById('endDate').value = o.endTime;//end[1];
                      
                      document.getElementById('startDateShow').value = o.startTimeLocal ;//start[1];
                      document.getElementById('endDateShow').value = o.startTimeLocal;//end[1];
                      
                  }                
            });
      //      getPeopleCount(valueSelected);            
        });              
    })
    
        
    var maxCount = 10;
    var date ;
    var sessions;
    function clickDate(check) { 
        date = check;
        jQuery.ajax({
            type: "POST",
            url: "<?php echo site_url('user/get_times'); ?>",
            dataType: 'json',
            data: {date: check, productCode: "<?php echo $data->product_code; ?>"},
            success: function (data) {
                if (data)
                {
                    // Show Entered Value                
                    units = data.sessions; 
                    sessions = units;
                    $("#time").empty();
                    var toAppend = '';
                    $.each(units,function(i,o){
                                                
                        startTimeLocal = o.startTime;
                        endTimeLocal = o.endTime;
                            
                        start = o.startTime.split("T"); //startTimeLocal
                        end = o.endTime.split("T"); //endTimeLocal
                                                                        
                        var now = new Date(o.startTime);
                        var hh = now.getHours();
                        var min = now.getMinutes();
                        var ampm = (hh>=12)?'pm':'am';
                        hh = hh%12;
                        hh = hh?hh:12;
                        hh = hh<10?'0'+hh:hh;
                        min = min<10?'0'+min:min;
                        var time = hh+" : "+min+" "+ampm;
                        
                        var now = new Date(o.endTime);
                        var hh = now.getHours();
                        var min = now.getMinutes();
                        var ampm = (hh>=12)?'pm':'am';
                        hh = hh%12;
                        hh = hh?hh:12;
                        hh = hh<10?'0'+hh:hh;
                        min = min<10?'0'+min:min;
                        var endTime = hh+" : "+min+" "+ampm;
                        
                        toAppend += '<option value=' + o.id +'>'+ time + '-' + endTime +'</option>';                        
                        if(i == 0){                                                        
                            document.getElementById('startDate').value = o.startTime;//start[1];
                            document.getElementById('endDate').value = o.endTime;//end[1];                            
                            document.getElementById('startDateShow').value = o.startTimeLocal ;//start[1];
                            document.getElementById('endDateShow').value = o.endTimeLocal;//end[1];                      
                        }
                        
                    });
                    $("#time").append(toAppend);                    
                }
            }
        });
    }    
        
    function getPeopleCount(time) {         
        jQuery.ajax({
            type: "POST",
            url: "<?php echo site_url('user/get_people_count'); ?>",
            dataType: 'json',
            data: {date: date, id: "<?php echo $id; ?>", time: time },
            success: function (data) {
                if (data)
                {
                    // Show Entered Value                                        
                    maxCount = data.count;                                                  
                }
            }
        });
    }
    
    
    
    function minmax(value, min, max) 
    {
        max = maxCount;
        if(parseInt(value) < min || isNaN(parseInt(value))) 
            return 1; 
        else if(parseInt(value) > max) 
            return max; 
        else return value;
    }
    
</script>