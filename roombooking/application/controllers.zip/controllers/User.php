<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

    public $apiKey;// = "e8057c57e6844309b8b511012e979c58";
    
    public function index() {
        
        $country = $this->db->get_where('country')->result_array();                        
        $res = $this->db->get_where('country', array('name'=>'us'))->row();
        if($res != null){
            $country_id  = $res->id;
            $city = $this->db->get_where('city', array('country_id'=>$country_id))->result_array();            
            //$tours = $this->db->get_where('tour', array('country_id'=>$country_id))->result_array();       
            $query = $this->db->query("SELECT * FROM tour WHERE country_id='".$country_id."' ORDER BY id DESC LIMIT 16");
            $tours = $query->result_array();                                
            $page_data['tours'] = $tours; 
            $page_data['country'] = $country; 
            $page_data['city'] = $city;      
            $page_data['country_id'] = $country_id;
            //$this->load->view('rezdy/common/header');  
            $this->load->view('rezdy/customer/index' , $page_data); 
            //$this->load->view('rezdy/common/footer');
        }        
    }    
    public function home($param1 = ''){        
        $country = $this->db->get_where('country')->result_array();                        
        $res = $this->db->get_where('country', array('id'=>$param1))->row();
        if($res != null){
            $country_id  = $param1;
            $city = $this->db->get_where('city', array('country_id'=>$country_id))->result_array();            
            $query = $this->db->query("SELECT * FROM tour WHERE country_id='".$country_id."' ORDER BY id DESC LIMIT 16");
            $tours = $query->result_array();
            $page_data['tours'] = $tours; 
            $page_data['country'] = $country; 
            $page_data['city'] = $city;     
            $page_data['country_id'] = $country_id;
            $this->load->view('rezdy/customer/index' , $page_data); 
        }
    }
        
    public function city_tours($param1 = ''){
        $tours = $this->db->get_where('tour', array('city_id'=>$param1))->result_array();
        $page_data['tours'] = $tours ;   
        $this->load->view('rezdy/customer/city_tours' , $page_data);
    }
        
    public function overview($param1 = '', $param2 = '', $param3 = ''){     
        
        $name1= str_replace("_"," ",urldecode($param1));
        $name2= str_replace(":","&",urldecode($name1));
        $myId = $this->db->get_where('tour', array('name'=> $name2 ))->row()->id;
       
        if($myId == "" || $myId == null){
            $country = $this->db->get_where('country')->result_array();                        
            $res = $this->db->get_where('country', array('name'=>'us'))->row();
            if($res != null){
                $country_id  = $res->id;
                $city = $this->db->get_where('city', array('country_id'=>$country_id))->result_array();            
                //$tours = $this->db->get_where('tour', array('country_id'=>$country_id))->result_array();       
                $query = $this->db->query("SELECT * FROM tour WHERE country_id='".$country_id."' ORDER BY id DESC LIMIT 16");
                $tours = $query->result_array();                                
                $page_data['tours'] = $tours; 
                $page_data['country'] = $country; 
                $page_data['city'] = $city;      
                $page_data['country_id'] = $country_id;
                //$this->load->view('rezdy/common/header');  
                $this->load->view('rezdy/customer/index' , $page_data); 
                //$this->load->view('rezdy/common/footer');
            }  
            return;
        }
        
        $page_data['id'] = $myId;
        $tour_id = $myId;
        
        $product_code = $this->db->get_where('tour', array('id'=>$tour_id))->row()->product_code;
        $results = json_decode(
            file_get_contents('https://api.rezdy.com/v1/products/'.$product_code.'?apiKey=e8057c57e6844309b8b511012e979c58'), true
        );
        //P5DMUH
        //PBENMK        
        $requestStatus = $results['requestStatus'];
        $success = $requestStatus['success'];                        
        if($success == true){            
            $tour = $results['product'];            
            //isset($search_array['first']);
            //array_key_exists('videos', $tour)
            if (array_key_exists('videos', $tour)) {
                
                $page_data['video'] = 1;
                $videos = $tour['videos'];
                if(count($videos) > 0){
                    $page_data['video_id'] = $tour['videos']['0']['id'];
                }else{
                    $page_data['video'] = 2;         
                    $page_data['images'] = $tour['images'];
                }               
            }else{
                
                $page_data['video'] = 2;         
                $page_data['images'] = $tour['images'];
            }                        
            $this->load->view('rezdy/customer/overview', $page_data);
        }
    }
    
    
    public function overview_hotel($param1 = '', $param2 = '', $param3 = ''){        
        $page_data['id'] = $param1;
        $tour_id = $param1;
        
        $restaurants = $this->db->get_where('restaurant', array('id'=>$tour_id))->row();//->product_code;        
        $page_data['id'] = $tour_id;
        $this->load->view('rezdy/customer/overview_hotel', $page_data);           
    }
    
    
    public function location($param1 = '', $param2 = '', $param3 = ''){   
        $page_data['id'] = $param1;
        $tour_id = $param1;        
        $this->load->view('rezdy/customer/location', $page_data);         
    }
    public function review($param1 = '', $param2 = '', $param3 = ''){                                
        $page_data['id'] = $param1;
        $this->load->view('rezdy/customer/review', $page_data);         
    }
    public function host($param1 = '', $param2 = '', $param3 = ''){                                
        $page_data['id'] = $param1;
        $this->load->view('rezdy/customer/host', $page_data);         
    }
        
    public function tours($param1 = '', $param2 = '', $param3 = ''){                                
        $page_data['id'] = $param1;            
        $tours = $this->db->get_where('tour')->result_array();        
        //$tours = $this->db->join('tour', 'city.id = tour.city_id')->result_array();        
        $country = $this->db->get_where('city')->result_array();
        
        $page_data['tours'] = $tours;
        $page_data['countries'] = $country;
        $this->load->view('rezdy/customer/tours', $page_data);                        
    
    }
    
    public function search($param1 = '', $param2 = '', $param3 = ''){                                
        $page_data['id'] = $param1;
        $this->load->view('rezdy/customer/search', $page_data);         
    }
    
     public function done($param1 = '', $param2 = '', $param3 = ''){                                        
        $this->load->view('rezdy/customer/done');
    }
    
    public function hotel_flight($param1 = '', $param2 = '', $param3 = ''){                                        
        $this->load->view('rezdy/customer/hotel_flight');
    }
    
    public function hotel($param1 = '', $param2 = '', $param3 = ''){
        
        $tours = $this->db->get_where('restaurant')->result_array();
        
        $MyObjects = array();
        foreach($tours as $roww){
            $res_id = $roww['id'];    
            $image = $this->db->get_where('res_image', array('res_id'=>$res_id))->row(); 
            if($image != null){                
                $roww['image'] = $image->image;
            }else{
                $roww['image'] = "";
            }                            
            $MyObjects[] = $roww;                
        }
        
//        $arr = array('sessions' => $MyObjects);
//        header('Content-Type: application/json');
//        echo json_encode($arr);                    
        $page_data['tours'] = $MyObjects;
        $this->load->view('rezdy/customer/hotel', $page_data);
    }
    
    
        
    
    
    public function contactus() {                               
        $this->load->database();        
        //$page_data['messages'] = $this->Messages_model->get_latest_messages();
        $this->load->view('rezdy/common/header');
        $this->load->view('rezdy/customer/contactus');
        $this->load->view('rezdy/common/footer');
    }
        
    public function contact(){
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $title = $this->input->post('title');
        $message = $this->input->post('message');
        
        $data['name'] = $name;
        $data['email'] = $email;
        $data['title'] = $title;
        $data['message'] = $message;
                                
        $this->db->insert('contact_us', $data);                
        $insert_id = $this->db->insert_id();
        $this->contactus();
    }
 
    
    public function blog() {                          
        $this->load->view('rezdy/common/header');
        $this->load->view('rezdy/customer/blog');
        $this->load->view('rezdy/common/footer');
    }

    public function testimonials() {                          
        $this->load->view('rezdy/common/header');
        $this->load->view('rezdy/customer/testimonials');
        $this->load->view('rezdy/common/footer');
    }
    
    public function blog_detail($param1) {
        //$this->load->view('rezdy/customer/blog_detail');                    
        $myId = $this->db->get_where('blog', array('title'=>  str_replace("_"," ",urldecode($param1))))->row()->id;
        $page_data['id'] = $myId;
        $this->load->view('rezdy/customer/blog_detail', $page_data); 
        
    }
    
    public function privacy_policy() {  
        $this->load->view('rezdy/common/header');
        $this->load->view('rezdy/customer/privacy_policy');
        $this->load->view('rezdy/common/footer');
    }
    
    
    public function terms() {
        $this->load->view('rezdy/common/header');
        $this->load->view('rezdy/customer/terms');
        $this->load->view('rezdy/common/footer');
    }
    public function faq() {      
        $this->load->view('rezdy/common/header');
        $this->load->view('rezdy/customer/faq');
        $this->load->view('rezdy/common/footer');
        
          
    
            
    }
    
    
    
    
    
    public function tours_bad($param1 = '', $param2 = '', $param3 = ''){
        
        $page_data['id'] = $param1;   
        //$countries = $this->db->get_where('city')->result_array();        
        $tours = json_decode(
            file_get_contents('https://api.rezdy.com/v1/products?apiKey=e8057c57e6844309b8b511012e979c58'), true
        );
        $requestStatus = $tours['requestStatus'];
        $success = $requestStatus['success'];                        
        if($success == true){
             $products = $tours['products'];        
             $page_data['tours'] = $products ;                                        
            $result = array();
            foreach($products as $row){
                if(!in_array( $row['locationAddress']['city'] , $result)  && $row['locationAddress']['city'] != ""){
                     array_push($result,$row['locationAddress']['city']);
                }      
            }
            $page_data['countries'] = $result;
            $this->load->view('rezdy/customer/tours', $page_data);     
        }        
    }
    
    public function get_times(){        
        $date = $this->input->post('date'); 
        $productCode = $this->input->post('productCode');        
        //echo 'https://api.rezdy.com/v1/availability/?productCode='.$productCode.'&apiKey=e8057c57e6844309b8b511012e979c58&startTime='.$date.'T00:00:00Z&endTime='.$date.'T23:59:00Z';
        $results = json_decode(
            file_get_contents('https://api.rezdy.com/v1/availability?productCode='.$productCode.'&apiKey=e8057c57e6844309b8b511012e979c58&startTime='.$date.'T00:00:00Z&endTime='.$date.'T23:59:00Z'), true
        );
        $requestStatus = $results['requestStatus'];
        $success = $requestStatus['success'];
        if($success == true){
            $sessions = $results['sessions'];
            $arr = array('sessions' => $sessions);
            header('Content-Type: application/json');
            echo json_encode($arr);
        }      
    }
        
    
    
    public function payment(){
        
        $page_data['date']        = $this->input->post('date');
        $page_data['time']        = $this->input->post('time');
        $page_data['startTime']        = $this->input->post('startDate');
        $page_data['endTime']        = $this->input->post('endDate');        
        $page_data['startTimeShow']        = $this->input->post('startDateShow');
        $page_data['endTimeShow']        = $this->input->post('endDateShow');        
        
        //$page_data['ticket_count']        = $this->input->post('guest');
        $page_data['tour_id']        = $this->input->post('tid');
        $page_data['coupon']        = $this->input->post('coupon');
        
        if($this->input->post('Quantity') != null){
            $page_data['quantity']     = $this->input->post('Quantity');
        }else{
            $page_data['quantity']     = "";
        }                
        if($this->input->post('Adult') != null){
            $page_data['adult'] = $this->input->post('Adult');
        }else{
            $page_data['adult'] = "";
        }
        if($this->input->post('Child') != null){
            $page_data['child'] = $this->input->post('Child');
        }else{
            $page_data['child'] = "";
        }        
                                       
        $voucher_code =  $this->input->post('coupon');        
        if($voucher_code != null && $voucher_code != ""){              
            $tours = json_decode(
                file_get_contents('https://api.rezdy.com/v1/vouchers/'.$voucher_code.'?apiKey=e8057c57e6844309b8b511012e979c58'), true
            );                
            $requestStatus = $tours['requestStatus'];
            $success = $requestStatus['success'];        
            if($success == true){            
                $voucher  = $tours['voucher'];            
                if (isset($voucher['value'])) {
                    $value = $voucher['value'];
                }else{
                    //$value = $voucher['code'];
                    $value = 100;
                }
                $page_data['value'] = $value;
            }else{
                $page_data['value'] = 0;
            }            
        }else{
            $page_data['value'] = 0;
        }        
        $this->load->view('rezdy/customer/payment', $page_data);
    }
    
    
    
    public function payment_hotel(){
                
        $res_id = $this->input->post('res_id');
        $supplier_code = $this->input->post('supplier_code');
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');
        $adult = $this->input->post('adult');
        $child = $this->input->post('child');

        $curl = curl_init();            
        curl_setopt_array($curl, array(
//                CURLOPT_PORT => 8080,
            CURLOPT_URL => "http://bluehorizons.com.ph:8080/iCom/servlet/conn",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POST => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_POSTFIELDS => '<?xml version="1.0"?>
                <!DOCTYPE Request SYSTEM "hostConnect_3_10_480.dtd">
                <Request>
                 <OptionInfoRequest>
                 <AgentID>SYTMUS</AgentID>
                 <Password>SYTMUS</Password>
                    <Opt>?????'.$supplier_code.'??????</Opt>
                 <Info>GMFTS</Info>
                 <DateFrom>'.$start_date.'</DateFrom>
                 <DateTo>'.$end_date.'</DateTo>
                 <RateConvert>Y</RateConvert>
                 <RoomConfigs>
                  <RoomConfig>
                    <Adults>'.$adult.'</Adults>
                    <Children>'.$child.'</Children>
                    <RoomType>TW</RoomType>
                   </RoomConfig>  
                 </RoomConfigs>
                 </OptionInfoRequest>
                </Request>',
          CURLOPT_HTTPHEADER => array(
              "Content-Type:text/plain",
            "cache-control: no-cache",
//                "postman-token: 4f3baf71-f22c-0f18-a2f2-127096d01b7a"
          )
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
         
        $suppliers = "";
        if ($err) {
          echo "cURL Error #:" . $err;
        } else {
          //echo $response;
          $suppliers = new SimpleXMLElement($response);                        
        }       
        
        $page_data['suppliers'] = $suppliers->OptionInfoReply;
        $page_data['res_id'] = $res_id;
        
        $page_data['supplier_code'] = $supplier_code;
        $page_data['adult'] = $adult;
        $page_data['child'] = $child;
        
        $page_data['adult_price'] = '33';
        $page_data['child_price'] = '44';
                
        $page_data['start_date'] = $start_date;
        $page_data['end_date'] = $end_date;
        $page_data['value'] = 0;
        
        $this->load->view('rezdy/customer/hotel_list', $page_data);
    }
    
    public function open_payment(){
        $code = $this->input->post('code');
        
        $res_id = $this->input->post('res_id');
        $adult = $this->input->post('adult');
        $child = $this->input->post('child');
        $price = $this->input->post('price');
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');
        
        
        $page_data['code'] = $code;        
        $page_data['res_id'] = $res_id;  
        $page_data['adult'] = $adult;
        $page_data['child'] = $child;
        
        $page_data['adult_price'] = $price;
        $page_data['child_price'] = $price;
                
        $page_data['startTime'] = $start_date;
        $page_data['endTime'] = $end_date;
        $page_data['value'] = 0;
        
        $this->load->view('rezdy/customer/payment_hotel', $page_data);
    }        
    
    
    public function book_hotel(){ 
        
        $code = $this->input->post('code');        
        $curl = curl_init();            
        curl_setopt_array($curl, array(
//                CURLOPT_PORT => 8080,
            CURLOPT_URL => "http://bluehorizons.com.ph:8080/iCom/servlet/conn",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POST => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_POSTFIELDS => '<?xml version="1.0"?>
                    <!DOCTYPE Request SYSTEM "hostConnect_3_00_000.dtd">
                    <Request>
                     <AddServiceRequest>
                      <AgentID>SYTMUS</AgentID>
                      <Password>SYTMUS</Password>
                      <NewBookingInfo>
                       <Name>Cooper Family </Name>
                       <QB>B</QB>
                      </NewBookingInfo>
                      <Opt>'.$code.'</Opt>
                      <RateId>Default</RateId>
                      <DateFrom>2017-12-24</DateFrom>
                      <RoomConfigs>
                       <RoomConfig>
                        <Adults>2</Adults>
                        <RoomType>DB</RoomType>
                        <PaxList>
                         <PaxDetails>
                          <Title>Mr.</Title>
                          <Forename>John</Forename>
                          <Surname>Cooper</Surname>
                          <PaxType>A</PaxType>
                         </PaxDetails>
                         <PaxDetails>
                          <Title>Mrs.</Title>
                          <Forename>Jane</Forename>
                          <Surname>Cooper</Surname>
                          <PaxType>A</PaxType>
                         </PaxDetails>
                        </PaxList>
                       </RoomConfig>
                       <RoomConfig>
                        <Adults>0</Adults>
                        <Children>2</Children>
                        <RoomType>TW</RoomType>
                        <PaxList>
                         <PaxDetails>
                          <Title>Miss</Title>
                          <Forename>Sarah</Forename>
                          <Surname>Cooper</Surname>
                          <PaxType>C</PaxType>
                         </PaxDetails>
                         <PaxDetails>
                          <Title>Miss</Title>
                          <Forename>Rebecca</Forename>
                          <Surname>Cooper</Surname>
                          <PaxType>C</PaxType>
                         </PaxDetails>
                        </PaxList>
                       </RoomConfig>
                      </RoomConfigs>
                      <SCUqty>1</SCUqty>
                      <Pickup_Date>2017-12-24</Pickup_Date>
                      <puTime>0800</puTime>
                      <puRemark>Collection from JFK International Terminal Flight KLZ345</puRemark>
                      <Dropoff_Date>2017-012-28</Dropoff_Date>
                      <doTime>1700</doTime>
                      <doRemark>Transfer to International Airport - Domestic Terminal Flight NB476 </doRemark>
                     </AddServiceRequest>
                    </Request>',
          CURLOPT_HTTPHEADER => array(
              "Content-Type:text/plain",
            "cache-control: no-cache",
//                "postman-token: 4f3baf71-f22c-0f18-a2f2-127096d01b7a"
          )
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
         
        $suppliers = "";
        if ($err) {
          echo "cURL Error #:" . $err;
        } else {
          //echo $response;
          $suppliers = new SimpleXMLElement($response);     
          
           $arr = array('response' => 200, 'data'=> $suppliers);
                header('Content-Type: application/json');                    
                echo json_encode($arr);                          
        }
        
//            "response": 200,
//    "data": {
//        "AddServiceReply": {
//            "BookingId": "110302",
//            "Ref": "MKIN198126",
//            "ServiceLineId": "293471",
//            "SequenceNumber": "10",
//            "Status": "RQ"
//        },
//        "BookingUpdateCount": "8",
//        "ServiceLineUpdateCount": "4"
//    }

        
        
//{"response":200,"data":{"AddServiceReply":{"BookingId":"110318","Ref":"MKIN198142","ServiceLineId":"293516","SequenceNumber":"10","Status":"RQ"},"BookingUpdateCount":"8","ServiceLineUpdateCount":"4"}}
    }
    
            
    public function make_payment(){        
        // customer info
        $firstName = $this->input->post('firstName');
        $lastName = $this->input->post('lastName');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');        
        $customer = array('firstName'=> $firstName, 'lastName'=>$lastName, 'email'=>$email, 'phone'=>$phone);  
        // item info
        $productCode = $this->input->post('productCode');
        $startTime = $this->input->post('startTime');
        $endTime = $this->input->post('endTime');
        $amount = $this->input->post('amount');
        
        $adult = $this->input->post('adult');
        $child = $this->input->post('child');
        $quantity = $this->input->post('quantity');
                                
        $quantitiesArray = array();
        if($quantity == null || $quantity == ""){            
            $adult_amount = $this->input->post('adult_amount');
            $child_amount = $this->input->post('child_amount');                        
            $quantities = array('optionLabel'=>'Adult','value'=>$adult, 'optionPrice'=>$adult_amount );
            $quantities2 = array('optionLabel'=>'Child','value'=>$child, 'optionPrice'=>$child_amount );
            array_push($quantitiesArray, $quantities);
            array_push($quantitiesArray, $quantities2);                        
        }else{                        
            $quantities = array('optionLabel'=>'Adult','value'=>$quantity, 'optionPrice'=>$amount );            
            array_push($quantitiesArray, $quantities);                                    
        }
                            
        $items = array('productCode'=>$productCode, 'startTime'=>$startTime,'endTime'=>$endTime, 'amount'=>$amount , 'quantities'=>$quantitiesArray);
        $itemArray = array();
        array_push($itemArray, $items);
        
        // credit card info  
        $cardName = 'VISA';//$this->input->post('cardName');
        $cardType = 'VISA';//$this->input->post('cardType');
        $expiryMonth = $this->input->post('expiryMonth');                              
        $expiryYear = $this->input->post('expiryYear');
        $cardNumber = $this->input->post('cardNumber');
        $cardSecurityNumber = $this->input->post('cardSecurityNumber');
        
        $creditCard = array('cardName'=>$cardName, 'cardType'=>$cardType, 'expiryMonth'=>$expiryMonth, 'expiryYear'=>$expiryYear, 'cardNumber'=>$cardNumber,'cardSecurityNumber'=>$cardSecurityNumber);
        $coupon = $this->input->post('coupon');
        $data = array('customer'=>$customer, 'items'=>$itemArray, 'paymentOption'=>'CREDITCARD','coupon'=>$coupon,  'creditCard'=>$creditCard);  

        //echo json_encode($data);        
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://api.rezdy.com/v1/bookings?apiKey=e8057c57e6844309b8b511012e979c58",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => json_encode($data),
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "content-type: application/json",
            "postman-token: 507b2faa-dbb0-cca1-2fbd-da99f97f6a67"
          ),
        ));        
        $response = curl_exec($curl);
        $err = curl_error($curl);
                        
        curl_close($curl);
        if ($err) {
          //echo "cURL Error #:" . $err;            
          $page_data['message'] = $err;
          $this->load->view('rezdy/customer/done', $page_data);
        } else {            
            
            $res = json_decode($response);
            //echo $res;
            $requestStatus = $res->requestStatus;
            $success = $requestStatus->success;  
            if($success == true){              
                $page_data['message'] = "Congratulations your reservation is confirmed and you should be receiving a confirmation shortly";
                $this->load->view('rezdy/customer/done', $page_data);
            }else{             
                $page_data['message'] = "Error: ".$requestStatus->error->errorMessage;
                $this->load->view('rezdy/customer/done', $page_data);
            }            
//              $page_data['message'] = "Payment was made successfully!!!";
//              $this->load->view('rezdy/customer/done', $page_data);
        }
    }

}
