<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
                $this->load->library('Client');

	}
        
        //102 E. Mayflower Ave.
        //Las Vegas Nevada 89030
        //United States
        //36.2123211,-115.1399658,17                
                
      public function syncAll(){
          
          //https://api.rezdy.com/v1/products?apiKey=e8057c57e6844309b8b511012e979c58          
          //https://api.rezdy.com/v1/categories/175134/products?apiKey=e8057c57e6844309b8b511012e979c58&search=Vegas
            $tours = json_decode(
                file_get_contents('https://api.rezdy.com/v1/products?apiKey=e8057c57e6844309b8b511012e979c58'), true
            );
            
            $requestStatus = $tours['requestStatus'];
            $success = $requestStatus['success'];                        
            if($success == true){
                // get tours
                $products = $tours['products'];        
                $page_data['tours'] = $products ;                        
                
                // get country and cities
                $country = array();
                foreach($products as $row){
                    $data = array(
                       'name'    =>    $row['locationAddress']['city']);                 
                    if(!in_array( $row['locationAddress']['countryCode'] , $country)  && $row['locationAddress']['countryCode'] != ""){
                         array_push($country,$row['locationAddress']['countryCode']);
                    }      
                }
                
                $results= array();
                foreach($country as $row){               
                    $city = array();
                    foreach($products as $row1){
                        if($row == $row1['locationAddress']['countryCode']){
                            
                            $temp = array('name' =>$row1['locationAddress']['city'], 'image'=>$row1['images'][0]['thumbnailUrl']);                            
                            if(!in_array( $temp , $city)  && $row1['locationAddress']['city'] != ""){
                                $da = array('name' =>$row1['locationAddress']['city'], 'image'=>$row1['images'][0]['thumbnailUrl']);
                                array_push($city, $da);
                            }                                                                                               
                        }
                    }
                    $data = array(
                           'name'    =>    $row, 'city' => $city); 
                    array_push($results,$data);    
                }           
                
                // intialze db.(country and city)
                foreach ($results as $myrow){                                        
                    $country_name = $myrow['name'];                    
                    $mydata['name'] = $country_name;  
                    $country_check = $this->db->get_where('country', array('name' => $country_name))->row();
                    if($country_check == null || $country_check == ""){                        
                        $this->db->insert('country',$mydata);  
                        $insert_id = $this->db->insert_id();
                    }else{                                                
                        $insert_id = $country_check->id;
                    }
                    $res = $myrow['city'];
                    $myarray = array();
                    foreach ($res as $sub_row){                        
                        $mydata1['name'] = $sub_row['name'];
                        $mydata1['image'] = $sub_row['image'];
                        $mydata1['country_id'] = $insert_id;      
                        $city_check = $this->db->get_where('city', array('name' => $sub_row['name']))->row();
                        if($city_check == null || $city_check == ""){
                            if($mydata1['image'] != null){
                                $this->db->insert('city', $mydata1);
                            }        
                        }                            
                    }
                }
                
                // initialize db(tours)
                foreach($products as $row){                                        
                    $product_code = $row['productCode'];                                       
                    $check = $this->db->get_where('tour', array('product_code'=>$product_code))->row();                    
                    $country_id = $this->db->get_where('country', array('name'=>$row['locationAddress']['countryCode']))->row()->id;
                    $city_id  = $this->db->get_where('city', array('name'=>$row['locationAddress']['city']))->row()->id;
                    if($check == null || $check == ""){
                        $dataa['name'] = $row['name'];
                        $dataa['image_url'] = $row['images'][0]['thumbnailUrl'];
                        if($dataa['image_url'] == null || $dataa['image_url'] == ""){
                            $dataa['image_url'] = "assets_extra/img/logo.png";
                        }	
                        $dataa['description'] = $row['description'];
                        //$dataa['video_url'] = $;                         
                        $dataa['city_id'] = $city_id;
                        $dataa['country_id'] = $country_id;                                                
                        $dataa['lat'] = $row['latitude'];
                        $dataa['lon'] = $row['longitude'];
                        $dataa['category_id'] = $row['supplierId'];
                        $dataa['provider_id'] = $row['supplierId'];
                        //$dataa['video_id'] = $this->input->post('video_id');   
                        //$dataa['max_count'] = $this->input->post('max_count');
                        $dataa['price'] = $row['advertisedPrice'];
                        
                        $priceOptions = $row['priceOptions'];
                                                                                                              
                        $this->db->where('productCode',  $row['productCode']);                               
                        $this->db->delete('priceoptions');
                        
                        foreach($priceOptions as $priceItem){
                            $priceData['price'] = $priceItem['price'];
                            $priceData['label'] = $priceItem['label'];
                            $priceData['seatsUsed'] = $priceItem['seatsUsed'];
                            $priceData['productCode'] = $priceItem['productCode'];                                  
                            $this->db->insert('priceoptions', $priceData);     
                        }
                        //$dataa['include'] = $this->input->post('include');   
                        //$dataa['know'] = $this->input->post('know');   
                        $dataa['summary'] = $row['shortDescription'];
                        $dataa['location'] = $row['locationAddress']['addressLine'];
                        $dataa['auto_confirm'] = $row['confirmMode'];
                        $dataa['product_code'] = $row['productCode'];
                        $dataa['tour_type'] = 1;
                        try{      
                            if($dataa['country_id'] != null && $dataa['city_id'] != null){
                                $check = $this->db->get_where('tour', array('product_code'=>$row['productCode']))->row();
                                if($check == null || $check == ""){
                                    $this->db->insert('tour', $dataa);
                                }else{
                                    $this->db->where('product_code', $row['productCode']);
                                    $this->db->update('tour', $dataa);
                                }                                                                
                            }
                        } catch (Exception $ex) {
                            echo 'error';
                        }                    
                    }                    
                }
                
                
                
                
                $page_data['page_name'] = 'tour_sync';
                $page_data['page_title'] = get_phrase('Sync tours');
                $this->load->view('index', $page_data);
        
        
//                $arr = array('response' => 200, 'tours'=> $products, 'country'=>$results);  
//                header('Content-Type: application/json');                    
//                echo json_encode($arr);                        
            } 
        }                        
                
        
        
        public function syncVegas(){
          
          //https://api.rezdy.com/v1/products?apiKey=e8057c57e6844309b8b511012e979c58          
          //https://api.rezdy.com/v1/categories/175134/products?apiKey=e8057c57e6844309b8b511012e979c58&search=Vegas
            $tours = json_decode(
                file_get_contents('https://api.rezdy.com/v1/categories/175134/products?apiKey=e8057c57e6844309b8b511012e979c58&search=Vegas'), true
            );
            
            $requestStatus = $tours['requestStatus'];
            $success = $requestStatus['success'];                        
            if($success == true){
                // get tours
                $products = $tours['products'];        
                $page_data['tours'] = $products ;                        
                
                // get country and cities
                $country = array();
                foreach($products as $row){
                    $data = array(
                       'name'    =>    $row['locationAddress']['city']);                 
                    if(!in_array( $row['locationAddress']['countryCode'] , $country)  && $row['locationAddress']['countryCode'] != ""){
                         array_push($country,$row['locationAddress']['countryCode']);
                    }      
                }
                
                $results= array();
                foreach($country as $row){               
                    $city = array();
                    foreach($products as $row1){
                        if($row == $row1['locationAddress']['countryCode']){
                            
                            $temp = array('name' =>$row1['locationAddress']['city'], 'image'=>$row1['images'][0]['thumbnailUrl']);                            
                            if(!in_array( $temp , $city)  && $row1['locationAddress']['city'] != ""){
                                $da = array('name' =>$row1['locationAddress']['city'], 'image'=>$row1['images'][0]['thumbnailUrl']);
                                array_push($city, $da);
                            }                                                                                               
                        }
                    }
                    $data = array(
                           'name'    =>    $row, 'city' => $city); 
                    array_push($results,$data);    
                }           
                
                // intialze db.(country and city)
                foreach ($results as $myrow){                                        
                    $country_name = $myrow['name'];                    
                    $mydata['name'] = $country_name;  
                    $country_check = $this->db->get_where('country', array('name' => $country_name))->row();
                    if($country_check == null || $country_check == ""){                        
                        $this->db->insert('country',$mydata);  
                        $insert_id = $this->db->insert_id();
                    }else{
                        $insert_id = $country_check->id;
                    }
                    $res = $myrow['city'];
                    $myarray = array();
                    foreach ($res as $sub_row){                        
                        $mydata1['name'] = $sub_row['name'];
                        $mydata1['image'] = $sub_row['image'];
                        $mydata1['country_id'] = $insert_id;      
                        $city_check = $this->db->get_where('city', array('name' => $sub_row['name']))->row();
                        if($city_check == null || $city_check == ""){
                            if($mydata1['image'] != null){
                                $this->db->insert('city', $mydata1);
                            }        
                        }                            
                    }
                }
                
                // initialize db(tours)
                foreach($products as $row){                                        
                    $product_code = $row['productCode'];                                       
                    $check = $this->db->get_where('tour', array('product_code'=>$product_code))->row();
                    $country_id = $this->db->get_where('country', array('name'=>$row['locationAddress']['countryCode']))->row()->id;
                    $city_id  = $this->db->get_where('city', array('name'=>$row['locationAddress']['city']))->row()->id;
                    if($check == null || $check == ""){
                        $dataa['name'] = $row['name'];
                        $dataa['image_url'] = $row['images'][0]['thumbnailUrl'];
                        if($dataa['image_url'] == null || $dataa['image_url'] == ""){
                            $dataa['image_url'] = "assets_extra/img/logo.png";
                        }	
                        $dataa['description'] = $row['description'];
                        //$dataa['video_url'] = $;                         
                        $dataa['city_id'] = $city_id;
                        $dataa['country_id'] = $country_id;                                                
                        $dataa['lat'] = $row['latitude'];
                        $dataa['lon'] = $row['longitude'];
                        $dataa['category_id'] = $row['supplierId'];
                        $dataa['provider_id'] = $row['supplierId'];
                        //$dataa['video_id'] = $this->input->post('video_id');   
                        //$dataa['max_count'] = $this->input->post('max_count');
                        $dataa['price'] = $row['advertisedPrice'];
                        
                        $this->db->where('productCode',  $row['productCode']);                               
                        $this->db->delete('priceoptions');
                        
                        $priceOptions = $row['priceOptions'];
                        foreach($priceOptions as $priceItem){
                            $priceData['price'] = $priceItem['price'];
                            $priceData['label'] = $priceItem['label'];
                            $priceData['seatsUsed'] = $priceItem['seatsUsed'];
                            $priceData['productCode'] = $priceItem['productCode'];
                            $this->db->insert('priceoptions', $priceData);     
                        }
                        //$dataa['include'] = $this->input->post('include');   
                        //$dataa['know'] = $this->input->post('know');   
                        $dataa['summary'] = $row['shortDescription'];
                        $dataa['location'] = $row['locationAddress']['addressLine'];
                        $dataa['auto_confirm'] = $row['confirmMode'];
                        $dataa['product_code'] = $row['productCode'];
                        $dataa['tour_type'] = 1;
                        try{      
                            if($dataa['country_id'] != null && $dataa['city_id'] != null){
                                                                
                                $check = $this->db->get_where('tour', array('product_code'=>$row['productCode']))->row();
                                if($check == null || $check == ""){
                                    $this->db->insert('tour', $dataa);
                                }else{
                                    $this->db->where('product_code', $row['productCode']);
                                    $this->db->update('tour', $dataa);
                                }   
                                
                            }                            
                        } catch (Exception $ex) {
                            echo 'error';
                        }                    
                    }                    
                }
                
                
                
                   
                $page_data['page_name'] = 'tour_sync';
                $page_data['page_title'] = get_phrase('Sync tours');
                $this->load->view('index', $page_data);
                
//                $arr = array('response' => 200, 'tours'=> $products, 'country'=>$results);  
//                header('Content-Type: application/json');                    
//                echo json_encode($arr);                        
            } 
        }    
        
        
        // thailand and vegas...
        //https://api.rezdy.com/v1/products/marketplace?apiKey=e8057c57e6844309b8b511012e979c58&search=thailand
        //https://api.rezdy.com/v1/categories/175134/products?apiKey=e8057c57e6844309b8b511012e979c58&search=Vegas
        
        public function sync_agent(){                        
            
            $tours = json_decode(
                file_get_contents('https://api.rezdy.com/v1/products/marketplace?apiKey=e8057c57e6844309b8b511012e979c58&search=thailand'), true
            );
            
            $requestStatus = $tours['requestStatus'];
            $success = $requestStatus['success'];                        
            if($success == true){
                // get tours
                $products = $tours['products'];        
                $page_data['tours'] = $products ;                        
                
                // get country and cities
                $country = array();
                foreach($products as $row){
//                    $data = array(
//                       'name'    =>    $row['locationAddress']['city']);   
                    if(!in_array( $row['locationAddress']['countryCode'] , $country)  && $row['locationAddress']['countryCode'] != ""){
                         array_push($country,$row['locationAddress']['countryCode']);
                    }      
                }
                
                $results= array();
                foreach($country as $row){               
                    $city = array();
                    foreach($products as $row1){                   
                            if($row == $row1['locationAddress']['countryCode']){                                                                    
                                if(isset($row1['locationAddress']['city'])){
                                   
                                     try{
//                                        if($row1['locationAddress']['city'] != "" && $row1['locationAddress']['city'] != null){                                    
//                                            $temp = array('name' =>$row1['locationAddress']['city'], 'image'=>$row1['images'][0]['thumbnailUrl']);                            
//                                            if(!in_array( $temp , $city)  && $row1['locationAddress']['city'] != ""){
//                                                $da = array('name' =>$row1['locationAddress']['city'], 'image'=>'image');
//                                                array_push($city, $da);
//                                            }   
//                                        }                                        
                                        if (strpos($row1['locationAddress']['addressLine'], 'Thailand') !== false && $row1['locationAddress']['countryCode'] == "th") {
                                            $pieces = explode(",", $row1['locationAddress']['addressLine']);
                                            if(is_numeric ($pieces[count($pieces) - 2])){
                                                $temp = array('name' =>trim($pieces[count($pieces) - 3]) , 'image'=>'assets_extra/img/city.png');                                                
                                                if(!in_array( $temp , $city)){
                                                    //$da = array( $pieces[count($pieces) - 3] , 'image'=>$row1['images'][0]['thumbnailUrl']);
                                                    array_push($city, $temp);
                                                }
                                            }else{
                                                $temp = array('name' =>  trim($pieces[count($pieces) - 2]) , 'image'=>'assets_extra/img/city.png');
                                                if(!in_array( $temp , $city)){
                                                    //$da = array( $pieces[count($pieces) - 2] , 'image'=>$row1['images'][0]['thumbnailUrl']);
                                                    array_push($city, $temp);
                                                }  
                                            }                                        
                                        }else{
                                            
                                            if($row1['locationAddress']['city'] != "" && $row1['locationAddress']['city'] != null){                                    
                                            $temp = array('name' =>$row1['locationAddress']['city'], 'image'=>$row1['images'][0]['thumbnailUrl']);                            
                                            if(!in_array( $temp , $city)  && $row1['locationAddress']['city'] != ""){
                                                $da = array('name' =>$row1['locationAddress']['city'], 'image'=>'image');
                                                array_push($city, $da);
                                            }
                                        }
                                        }                                    
                                    } catch (Exception $ex) {
                                    }  
                                }                              
                            }                                             
                    }
                    $data = array(
                           'name'    =>    $row, 'city' => $city); 
                    array_push($results,$data);    
                }  
                
                
//                $arr = array('response' => 200, 'res'=> $results);
//                header('Content-Type: application/json');                    
//                echo json_encode($arr);                  
                
                // intialze db.(country and city)
                foreach ($results as $row){                                        
                    $country_name = $row['name'];                    
                    $mydata['name'] = $country_name;  
                    $country_check = $this->db->get_where('country', array('name' => $country_name))->row();
                    if($country_check == null || $country_check == ""){
                        $this->db->insert('country',$mydata);  
                        $insert_id = $this->db->insert_id();                                                
                    }else{
                        $insert_id  = $country_check->id;
                    }                    
                    $res = $row['city'];
                    $myarray = array();
                    foreach ($res as $sub_row){                        
                        $mydata1['name'] = $sub_row['name'];
                        $mydata1['image'] = $sub_row['image'];
                        $mydata1['country_id'] = $insert_id;      
                        $city_check = $this->db->get_where('city', array('name' => $sub_row['name']))->row();
                        if($city_check == null || $city_check == ""){
                            $this->db->insert('city', $mydata1);
                        }                            
                    }
                }
                                
                // initialize db(tours)
                foreach($products as $row){                                        
                    $product_code = $row['productCode'];                                       
                    $check = $this->db->get_where('tour', array('product_code'=>$product_code))->row();
                    $country_id = $this->db->get_where('country', array('name'=>$row['locationAddress']['countryCode']))->row()->id;
                                        
                    $pieces = explode(",", $row['locationAddress']['addressLine']);
                              
                    if((count($pieces) - 2) >= 0){
                        if(is_numeric ($pieces[count($pieces) - 2])){  
                            if((count($pieces) - 3) >= 0){
                                $city_id  = $this->db->get_where('city', array('name'=>trim($pieces[count($pieces) - 3])))->row()->id;
                            }                         
                        }else{                        
                            if((count($pieces) - 2) >= 0){
                                $city_id  = $this->db->get_where('city', array('name'=>trim($pieces[count($pieces) - 2])))->row()->id;          
                            }
                        }
                    }
                    
                    if($check == null || $check == ""){
                        $dataa['name'] = $row['name'];
                        $dataa['image_url'] = $row['images'][0]['thumbnailUrl'];
                        if($dataa['image_url'] == null || $dataa['image_url'] == ""){
                            $dataa['image_url']  = "assets_extra/img/logo.png";
                        }
                        $dataa['description'] = $row['description'];
                        //$dataa['video_url'] = $;                         
                        $dataa['city_id'] = $city_id;
                        $dataa['country_id'] = $country_id;                                                
                        $dataa['lat'] = $row['latitude'];
                        $dataa['lon'] = $row['longitude'];
                        $dataa['category_id'] = $row['supplierId'];
                        $dataa['provider_id'] = $row['supplierId'];
                        //$dataa['video_id'] = $this->input->post('video_id');   
                        //$dataa['max_count'] = $this->input->post('max_count');
                        $dataa['price'] = $row['advertisedPrice'] * 1.2;
                        //$dataa['include'] = $this->input->post('include');   
                                                
                        $priceOptions = $row['priceOptions'];
                        
                        $this->db->where('productCode',  $row['productCode']);                               
                        $this->db->delete('priceoptions');
                        
                        foreach($priceOptions as $priceItem){
                            $priceData['price'] = $priceItem['price'];
                            $priceData['label'] = $priceItem['label'];
                            $priceData['seatsUsed'] = $priceItem['seatsUsed'];
                            $priceData['productCode'] = $priceItem['productCode'];
                            $this->db->insert('priceoptions', $priceData);     
                        }
                        
                        //$dataa['know'] = $this->input->post('know'); 
                        $dataa['summary'] = $row['shortDescription'];
                        $dataa['location'] = $row['locationAddress']['addressLine'];
                        $dataa['auto_confirm'] = 1;//$row['confirmMode'];
                        $dataa['product_code'] = $row['productCode'];
                        $dataa['tour_type'] = 2;
                        try{                                
                            if($dataa['country_id'] != null){                                
                                $check = $this->db->get_where('tour', array('product_code'=>$row['productCode']))->row();
                                if($check == null || $check == ""){
                                    $this->db->insert('tour', $dataa);
                                }else{
                                    $this->db->where('product_code', $row['productCode']);
                                    $this->db->update('tour', $dataa);
                                }   
                                
                            }                            
                        } catch (Exception $ex) {
                            echo 'error';
                        }                    
                    }                    
                }
                
                
                
                   
                $page_data['page_name'] = 'tour_sync';
                $page_data['page_title'] = get_phrase('Sync tours');
                $this->load->view('index', $page_data);
                
                
//                $arr = array('response' => 200, 'tours'=> $products, 'country'=>$results);  
//                header('Content-Type: application/json');                    
//                echo json_encode($arr);                        
            }
        }
        
                
        public function getYelp(){

            $this->load->library('Client');
            $client = new Client(array(
                'accessToken' => '_zy7YWXUaWLrnlzgu9lDpmKZWzwCvXg97xPlV8N3-o59UVpWqhr21OBfxqSyh8pxAMef9bmBiQ6Hddy4UJOWCP6Ocgh7vIdtkCb0IqmTG1e1dw4FRaJKAU0-84JcWnYx',
            ));

                        echo "xxxx";
//            // Create a new guzzle http client
//            $specialHttpClient = new \GuzzleHttp\Client([
//                // ... some special configuration
//            ]);
//
//            // Update the yelp client with the new guzzle http client
//            // then get business data
//            $business = $client->setHttpClient($specialHttpClient)
//                ->getBusiness('the-motel-bar-chicago');
//
//            // Create request for other yelp API resource not supported by yelp-php
//            $request = $client->getRequest('GET', '/v3/some-future-endpoint');
//
//            // Send that request
//            $response = $client->getResponse($request);
//
//            // See the contents
//            echo $response->getBody();
        }
        
        
        
        public function getPriceOption(){            
            $productCode = $this->input->post('productCode');
            $priceoptions = $this->db->get_where('priceoption', array('productCode'=>$productCode))->result_array();  
            $arr = array('response' => 200, 'priceoptions'=> $priceoptions);
            header('Content-Type: application/json');                    
            echo json_encode($arr);            
        }
        
        
        public function myTest(){
            echo "xxx";
        }
        
        
        
        
        
        public function syncXml(){       
            
            $curl = curl_init();            
            curl_setopt_array($curl, array(
//                CURLOPT_PORT => 8080,
                CURLOPT_URL => "http://bluehorizons.com.ph:8080/iCom/servlet/conn",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => false,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 120,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POST => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_POSTFIELDS => '<?xml version="1.0"?>
                <!DOCTYPE Request SYSTEM "hostConnect_3_10_480.dtd">
                 <Request>
                         <SupplierInfoRequest>
                         <AgentID>SYTMUS</AgentID>
                         <Password>SYTMUS</Password>
                         <SupplierCode>??????</SupplierCode>
                         </SupplierInfoRequest>
                 </Request>',
              CURLOPT_HTTPHEADER => array(
                  "Content-Type:text/plain",
                "cache-control: no-cache",
//                "postman-token: 4f3baf71-f22c-0f18-a2f2-127096d01b7a"
              )
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              //echo $response;
              $suppliers = new SimpleXMLElement($response);
                                         
              //echo $suppliers->SupplierInfoReply->Suppliers->Supplier->count();             
              
              for($i = 0 ; $i < 2800; $i++){                                  //$suppliers->SupplierInfoReply->Suppliers->Supplier->count()
                $supplierId = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->SupplierId;
                $supplierCode = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->SupplierCode;
                $supplierName = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->Name;
                $address1 = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->Address1;
                $address2 = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->Address2;
                $address3 = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->Address3;
                $address4 = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->Address4;

                try{
                    $postCode = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->PostCode;
                } catch (Exception $ex) {
                }
                try{
                    $phone = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->Phone;
                } catch (Exception $ex) {
                    
                }
                try{
                    $email = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->Email;
                } catch (Exception $ex) {
                }
                try{
                    $web = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->Web;
                } catch (Exception $ex) {
                }
                try{
                    $fax = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->Fax;
                } catch (Exception $ex) {
                }
                
                 
                
                $supplierNotes = $suppliers->SupplierInfoReply->Suppliers->Supplier[$i]->SupplierNotes;                
                if($supplierNotes != null && $supplierNotes != ""){                 
                     
                    // add country                                    
//                    $country_data['name'] = $address4;
//                    $country_check = $this->db->get_where('country', array('name'=>$address4))->row();                    
//                    if($country_check == null || $country_check == ""){
//                        $this->db->insert('country', $country_data);
//                        $country_id = $this->db->insert_id();                        
//                    }else{
//                        $country_id = $country_check->id;
//                    }                                              
                    // add city 
//                    $city_data['name'] = $address3;
//                    $city_check = $this->db->get_where('city', array('name'=>$address3))->row();
//                    if($city_check == null || $city_check == ""){
//                        $this->db->insert('city', $city_data);
//                    }else{
//                        $city_id = $city_check->id;
//                    }
                       
                    
                    $data['name']        = $supplierName;
                    $data['supplier_code'] = $supplierCode;
                    $data['address1']        = $address1;
                    $data['address2']        = $address2;
                    $data['address3']        = $address3;
                    $data['address4']        = $address4;                    
                    $data['post_code']        = $postCode;
                    $data['phone']        = $phone;
                    $data['email']        = $email;
                    $data['fax']        = $fax;
                    $data['web']        = $web;
                    
                    $data['details'] = "";
                    $data['chd'] = "";
                   
                    $check = $this->db->get_where('restaurant', array('supplier_code'=>$supplierCode))->row(); 
                    if($check == null || $check == "") {
                                                                                                                     
                        for($j = 0; $j <  $supplierNotes->SupplierNote->count(); $j++){
                                $category = $supplierNotes->SupplierNote[$j]->NoteCategory;                                                                
                                if($category == "ISN"){
                                    $details = $supplierNotes->SupplierNote[$j]->NoteText;
                                    $data['details'] = $details;                                    
                                }else{
                                    if($data['details'] == ""){
                                        $data['details'] = "empty";
                                    }                                    
                                }
                                                                
                                if($category == "CHD"){
                                    $chd = $supplierNotes->SupplierNote[$j]->NoteText;
                                    $data['chd'] = $chd;
                                }else{
                                    if($data['chd'] == ""){
                                        $data['chd'] = "empty";
                                    }                                    
                                }
                                                                                               
                                if($category == "SUI"){                                    
                                    $this->db->insert('restaurant', $data);                                    
                                    $insert_id = $this->db->insert_id();                        
                                    
                                    $urls = $supplierNotes->SupplierNote[$j]->NoteText;                                    
                                    $pieces = explode("\n\n", $urls);  
                                    for($k = 0; $k < count($pieces) ; $k++){
                                        if($pieces[$k] != null && trim($pieces[$k]) != ""){
                                            $img_data['res_id'] = $insert_id;
                                            $img_data['image'] = $pieces[$k];
                                            $this->db->insert('res_image', $img_data);
                                        }                                        
                                    }                                                                        
                                }
                        }
                    }                                       
                }
              }                        
              //$character = $movies->movie[0]->characters->addChild('character');              
//                $character->addChild('name', 'Mr. Parser');
//                $character->addChild('actor', 'John Doe');
//
//                $rating = $movies->movie[0]->addChild('rating', 'PG');
//                $rating->addAttribute('type', 'mpaa');
            }                        
        }
        
        
        
        public function bookHotel(){
                        
            $supplier_code = $this->input->post('supplier_code');
            $start_date = $this->input->post('start_date');
            $end_date = $this->input->post('end_date');
            $adult = $this->input->post('adult');
            $child = $this->input->post('child');
                                   
            $curl = curl_init();            
            curl_setopt_array($curl, array(
//                CURLOPT_PORT => 8080,
                CURLOPT_URL => "http://bluehorizons.com.ph:8080/iCom/servlet/conn",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER => false,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 120,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POST => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_POSTFIELDS => '<?xml version="1.0"?>
                    <!DOCTYPE Request SYSTEM "hostConnect_3_10_480.dtd">
                    <Request>
                     <OptionInfoRequest>
                     <AgentID>SYTMUS</AgentID>
                     <Password>SYTMUS</Password>
                        <Opt>?????'.$supplier_code.'??????</Opt>
                     <Info>GMFTS</Info>
                     <DateFrom>'.$start_date.'</DateFrom>
                     <DateTo>'.$end_date.'</DateTo>
                     <RateConvert>Y</RateConvert>
                     <RoomConfigs>
                      <RoomConfig>
                        <Adults>'.$adult.'</Adults>
                        <Children>'.$child.'</Children>
                        <RoomType>TW</RoomType>
                       </RoomConfig>  
                     </RoomConfigs>
                     </OptionInfoRequest>
                    </Request>',
              CURLOPT_HTTPHEADER => array(
                  "Content-Type:text/plain",
                "cache-control: no-cache",
//                "postman-token: 4f3baf71-f22c-0f18-a2f2-127096d01b7a"
              )
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
              //echo $response;
              $suppliers = new SimpleXMLElement($response);              
              $arr = array('response'=>200, 'info' => $suppliers);
              header('Content-Type: application/json');               
              echo json_encode($arr);                      
            }
        }        
        public function syncTest(){            
            $request = new HttpRequest();
            $request->setUrl('http://bluehorizons.com.ph:8080/iCom/servlet/conn');
            $request->setMethod(HTTP_METH_POST);

            $request->setHeaders(array(
              'postman-token' => 'c84f5a79-b779-949c-7c29-19c6460caba7',
              'cache-control' => 'no-cache'
            ));

            $request->setBody('<?xml version="1.0"?>

            <!DOCTYPE Request SYSTEM "hostConnect_3_10_480.dtd">
             <Request>
                     <SupplierInfoRequest>
                     <AgentID>SYTMUS</AgentID>
                     <Password>SYTMUS</Password>
                     <SupplierCode>??????</SupplierCode>
                     </SupplierInfoRequest>
             </Request>
            ');

            try {
              $response = $request->send();

              echo $response->getBody();
            } catch (HttpException $ex) {
              echo $ex;
            }
        }
        
        
        
        public function getNearBy($param1 = '', $param2 = '', $param3 = ''){
        
        $latitude = 32;
        $longitude = -117;                
        $latitude = $this->input->post('lat');
        $longitude = $this->input->post('lng');
        
        $multiply = 1;
        $distance = 4000;
        $query = "SELECT "
                            . "tour.*, "
                            . "ROUND(" . $multiply . " * 3956 * acos( cos( radians('$latitude') ) * "
                            . "cos( radians(lat) ) * "
                            . "cos( radians(lon) - radians('$longitude') ) + "
                            . "sin( radians('$latitude') ) * "
                            . "sin( radians(lat) ) ) ,8) as distance "
                            . "from tour "
                            . "where "                                                        
                            . "ROUND((" . $multiply . " * 3956 * acos( cos( radians('$latitude') ) * "
                            . "cos( radians(lat) ) * "
                            . "cos( radians(lon) - radians('$longitude') ) + "
                            . "sin( radians('$latitude') ) * "
                            . "sin( radians(lat) ) ) ) ,8) <= $distance "            ;
                            //. "order by distance";
        
        $res = $this->db->query($query)->result_array();
        $arr = array('response'=>200, 'tour' => $res);
        header('Content-Type: application/json');
        echo json_encode($arr);                 
    }
    
        
    public function getTourByName($param1 = '', $param2 = '', $param3 = ''){
                  
        $name = $this->input->post('name');
        $query = "SELECT * FROM tour WHERE name like '%".$name."%'";
        $res = $this->db->query($query)->result_array();                
        $arr = array('response'=>200, 'tours' => $res);
        header('Content-Type: application/json');
        echo json_encode($arr);                 
    }


    
    public function getTourByCountryId($param1 = '', $param2 = '', $param3 = ''){
                  
        $country_id = $this->input->post('id');        
        $query = $this->db->query("SELECT * FROM tour WHERE country_id='".$country_id."' ORDER BY id DESC");
        $tours = $query->result_array();
                                    
        $arr = array('tours' => $tours);
        header('Content-Type: application/json');
        echo json_encode($arr);                 
    }
    public function getToursByCity(){        
        $country_id = $this->input->post('city_id');        
        $query = $this->db->query("SELECT * FROM tour WHERE city_id='".$country_id."' ORDER BY id DESC");
        $tours = $query->result_array();
                                    
        $arr = array('response'=>200, 'tours' => $tours);
        header('Content-Type: application/json');
        echo json_encode($arr);   
    }
    
    
    function loadBaseData(){        
        $user_id = $this->input->post('user_id');    
        $country_id = $this->input->post('country_id');        
        if($country_id == -1){         
            $country_id = $this->db->get_where('country', array('code'=>'USA'))->row()->id;                                
        }
        
        $country = $this->db->get('country')->result_array();            
        $query = $this->db->query("SELECT * FROM tour WHERE country_id='".$country_id."' ORDER BY id DESC LIMIT 30");                                
        $new_tours = $query->result_array();

        $query = $this->db->query("SELECT * FROM tour WHERE country_id='".$country_id."' and rate >= 4 ORDER BY id DESC LIMIT 30");                     
        $top_tours = $query->result_array();
        $cities = $this->db->get_where('city', array('country_id'=>$country_id))->result_array();

        $reservations = $this->db->get_where('reservation', array('user_id'=>$user_id))->result_array();        
        $MyObjects = array();          
        foreach($reservations as $row){
                $rsv_id = $row['id'];
                $tour_id = $row['tour_id'];
                $tours = $this->db->get_where('tour', array('id'=>$tour_id))->row();
                $item = array('rsv_id'=>$rsv_id, 'tour_id'=>$tour_id,'user_id'=>$row['user_id']);                 
                $MyObject['reservation'] = $row;
                $MyObject['tours'] = $tours;                
                $MyObjects[] = $MyObject;                
        }                 
        $arr = array('response'=> '200', 'new_tours'=>$new_tours,'top_tours'=>$top_tours, 'cities'=>$cities, 'reservations'=>$MyObjects, 'country'=>$country); 
        header('Content-Type: application/json');
        echo json_encode($arr);   
    }
    
    function getCity(){
        $cid = $this->input->post('country_id');
        if($cid == -1){
             $cities = $this->db->get('city')->result_array();
        }else{
             $cities = $this->db->get_where('city', array('id'=>$cid))->result_array();
        }        
        $arr = array('response'=> '200', 'cities'=>$cities); 
        header('Content-Type: application/json');
        echo json_encode($arr);            
    }
     
    function getBlog(){                        
        $itemCount = "30";
        $offset = $this->input->post('offset') * $itemCount;
        $sql = "SELECT * FROM blog ORDER BY id DESC limit ".$itemCount." offset ".$offset."";
        $query = $this->db->query($sql);                  
        $blogs = $query->result_array();
                
        $arr = array('response'=> '200', 'blog'=>$blogs); 
        header('Content-Type: application/json');
        echo json_encode($arr);        
    }
    
    function getReservations(){
        $user_id = $this->input->post('user_id');
        $reservations = $this->db->get_where('reservation', array('user_id'=>$user_id))->result_array();        
        $MyObjects = array();          
        foreach($reservations as $row){
                $rsv_id = $row['id'];
                $tour_id = $row['tour_id'];
                $tours = $this->db->get_where('tour', array('id'=>$tour_id))->row();                                
                $MyObject['reservation'] = $row;
                $MyObject['tours'] = $tours;
                $MyObjects[] = $MyObject;                
        }                 
        $arr = array('response'=> '200','reservations'=>$MyObjects); 
        header('Content-Type: application/json');
        echo json_encode($arr);   
    }
    
     function getProductDetails(){          
        $product_code = $this->input->post('product_code');//$this->db->get_where('tour', array('id'=>$tour_id))->row()->product_code;                
        $results = json_decode(
            file_get_contents('https://api.rezdy.com/v1/products/'.$product_code.'?apiKey=e8057c57e6844309b8b511012e979c58'), true
        );
        $requestStatus = $results['requestStatus'];
        $success = $requestStatus['success'];                        
        if($success == true){
            $tour =  $results['product'];            
            if (array_key_exists('videos', $tour)) {
                $tour['video'] = 1;
                $tour['video_id'] = $tour['videos']['0']['id'];
            }else{
                $tour['video'] = 2;
                $tour['images'] = $tour['images'];
            }
            $arr = array('response'=> '200', 'tour'=>$tour); 
            header('Content-Type: application/json');
            echo json_encode($arr);   
        }else{
            $arr = array('response'=> '400'); 
            header('Content-Type: application/json');
            echo json_encode($arr);   
        
        }            
    }
            
     public function login(){        
        //$password  = $this->input->post('password');
        //$email = $this->input->post('email');        
        $password = $_POST["password"];
        $email = $_POST["email"];
        
        
        $row = $this->db->get_where('usertable', array('email'=>$email, 'password'=>$password))->row();
        if($row == null || $row == ""){            
            $arr = array('response'=> '400'); 
            header('Content-Type: application/json');
            echo json_encode($arr);   
        }else{
            $user_id = $row->no;
            $reservations = $this->db->get_where('reservation', array('user_id'=>$user_id))->result_array();        
            $MyObjects = array();
            foreach($reservations as $roww){
                    $rsv_id = $roww['id'];
                    $tour_id = $roww['tour_id'];
                    $tours = $this->db->get_where('tour', array('id'=>$tour_id))->row();                                
                    $MyObject['reservation'] = $roww;
                    $MyObject['tours'] = $tours;                
                    $MyObjects[] = $MyObject;                
            }    
        
            $arr = array('response'=> '200' , 'user'=>$row, 'reservations'=>$MyObjects); 
            header('Content-Type: application/json');
            echo json_encode($arr);   
        }
     }
     
     
     public function register(){
         
        $data['name']        = $this->input->post('fname');
        $data['surname']        = $this->input->post('lname');
        $data['email']        = $this->input->post('email');
        $data['phone']        = $this->input->post('phone');
        $data['password']        = $this->input->post('password');	
        $data['user_type']       = '4'; // customer
        
        $exist = $this->db->get_where('usertable', array('email' => $this->input->post('email')))->row();
        if( ($exist == null) || ($exist == "") ){
            $this->db->insert('usertable', $data);            
            $insert_id = $this->db->insert_id();
            
            $row = $this->db->get_where('usertable', array('no'=>$insert_id))->row();            
            $reservations = $this->db->get_where('reservation', array('user_id'=>$insert_id))->result_array();        
            $MyObjects = array();
            foreach($reservations as $roww){
                    $rsv_id = $roww['id'];
                    $tour_id = $roww['tour_id'];
                    $tours = $this->db->get_where('tour', array('id'=>$tour_id))->row();                                
                     $MyObject['reservation'] = $roww;
                    $MyObject['tours'] = $tours;
                    $MyObjects[] = $MyObject;                
            }
            
            $arr = array('response'=> '200' , 'user'=>$row, 'reservations'=>$MyObject); 
            header('Content-Type: application/json');
            echo json_encode($arr);               
        }else{              
            $arr = array('response'=> '400'); 
            header('Content-Type: application/json');
            echo json_encode($arr); 
        }
                
     }
 
     
      public function get_times(){  
        $date = $this->input->post('date');
        $productCode = $this->input->post('productCode');        
        //echo 'https://api.rezdy.com/v1/availability/?productCode='.$productCode.'&apiKey=e8057c57e6844309b8b511012e979c58&startTime='.$date.'T00:00:00Z&endTime='.$date.'T23:59:00Z';
        $results = json_decode(
            file_get_contents('https://api.rezdy.com/v1/availability?productCode='.$productCode.'&apiKey=e8057c57e6844309b8b511012e979c58&startTime='.$date.'T00:00:00Z&endTime='.$date.'T23:59:00Z'), true
        );
        $requestStatus = $results['requestStatus'];
        $success = $requestStatus['success'];
        if($success == true){
            $sessions = $results['sessions'];
            $arr = array('response'=>200, 'sessions' => $sessions);
            header('Content-Type: application/json');
            echo json_encode($arr);
        }else{
            $arr = array('response' => 400);
            header('Content-Type: application/json');
            echo json_encode($arr);
        }  
    }
    
    public function getOrders(){
            $tours = json_decode(
                file_get_contents('https://api.rezdy.com/v1/bookings?apiKey=e8057c57e6844309b8b511012e979c58'), true
            );
            $requestStatus = $tours['requestStatus'];
            $success = $requestStatus['success'];                        
            if($success == true){
                $bookings = $tours['bookings'];                 
                $arr = array('response' => 200, 'bookings'=>$bookings);
                header('Content-Type: application/json');
                echo json_encode($arr);
            }else{
                $arr = array('response' => 400);
                header('Content-Type: application/json');
                echo json_encode($arr);
            }                        
    }

    public function getVoucherCode(){
        
        $voucher_code = $this->input->post('code');
        $tours = json_decode(
            file_get_contents('https://api.rezdy.com/v1/vouchers/'.$voucher_code.'?apiKey=e8057c57e6844309b8b511012e979c58'), true
        );
                
        $requestStatus = $tours['requestStatus'];
        $success = $requestStatus['success'];
        
        if($success == true){
            
            $voucher  = $tours['voucher'];            
            if (isset($voucher['value'])) {
                $value = $voucher['value'];
            }else{
                $value = $voucher['code'];
            }            
            $arr = array('response' => 200, 'value'=> $value);
            header('Content-Type: application/json');
            echo json_encode($arr);
            
        }else{            
            $arr = array('response' => 400);
            header('Content-Type: application/json');
            echo json_encode($arr);            
        }            
    }
    

    
    
    public function cancelReservation(){
                
        $rsv_id = $this->input->post('rsv_id');
        $product_code = $this->input->post('product_code');        
        
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://api.rezdy.com/v1/bookings/".$product_code."?apiKey=e8057c57e6844309b8b511012e979c58",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "DELETE",
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "postman-token: 0324b533-a3e1-bf3a-288f-7d5b30a3c384"
          ),
        ));
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
          //echo "cURL Error #:" . $err;
            $arr = array('response'=>400, 'message' => $err);
            header('Content-Type: application/json');
            echo json_encode($arr);
        } else {                         
            $res = json_decode($response, true);                                   
            $requestStatus = $res['requestStatus'];
            $success = $requestStatus['success'];
            if($success == true){                
                $dataa['state'] = 3;
                $this->db->where('id', $rsv_id);
                $this->db->update('reservation', $dataa);
                $arr = array('response'=>200, 'message' => "");
                header('Content-Type: application/json');
                echo json_encode($arr);
            }else{                
                $error = $requestStatus['error'];
                $message = $error['errorMessage'];
                $arr = array('response'=>400, 'message' => $message);
                header('Content-Type: application/json');
                echo json_encode($arr);
            }          
        }        
    }

    
    public function make_payment(){    
        // customer info
        $firstName = $this->input->post('firstName');
        $lastName = $this->input->post('lastName');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        
                
        $customer = array('firstName'=> $firstName, 'lastName'=>$lastName, 'email'=>$email, 'phone'=>$phone);  
        // item info
        $productCode = $this->input->post('productCode');
        $startTime = $this->input->post('startTime');
        $endTime = $this->input->post('endTime');
        $coupon= $this->input->post('coupon');
                
        $adult = $this->input->post('adult');
        $child = $this->input->post('child');
        
        $quantitiesArray = array();        
        $adult_amount = $this->input->post('adult_amount');
        $child_amount = $this->input->post('child_amount');
        
        $quantities = array('optionLabel'=>'Adult','value'=>$adult, 'optionPrice'=>$adult_amount );
        array_push($quantitiesArray, $quantities);
         
        if($child != 0 && $child_amount != 0){
           $quantities2 = array('optionLabel'=>'Child','value'=>$child, 'optionPrice'=>$child_amount );        
           array_push($quantitiesArray, $quantities2);                    
        }
//        $quantities = array('optionLabel'=>'Adult','value'=>$people, 'optionPrice'=>$amount );
//        $quantitiesArray = array();
//        array_push($quantitiesArray, $quantities);
//        
        $items = array('productCode'=>$productCode, 'startTime'=>$startTime,'endTime'=>$endTime, 'amount'=>$amount , 'quantities'=>$quantitiesArray);
        $itemArray = array();
        array_push($itemArray, $items);
        
        // credit card info  
        $cardName = $this->input->post('cardName');
        $cardType = 'VISA';//$this->input->post('cardType');
        $expiryMonth = $this->input->post('expiryMonth');                              
        $expiryYear = $this->input->post('expiryYear');
        $cardNumber = $this->input->post('cardNumber');
        $cardSecurityNumber = $this->input->post('cardSecurityNumber');
        
        $creditCard = array('cardName'=>$cardName, 'cardType'=>$cardType, 'expiryMonth'=>$expiryMonth, 'expiryYear'=>$expiryYear, 'cardNumber'=>$cardNumber,'cardSecurityNumber'=>$cardSecurityNumber);               
        $data = array('customer'=>$customer, 'items'=>$itemArray, 'paymentOption'=>'CREDITCARD','coupon'=>$coupon, 'creditCard'=>$creditCard);               
        //echo json_encode($data);
                
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://api.rezdy.com/v1/bookings?apiKey=e8057c57e6844309b8b511012e979c58",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => json_encode($data),
          CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache",
            "content-type: application/json",
            "postman-token: 507b2faa-dbb0-cca1-2fbd-da99f97f6a67"
          ),
        ));        
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        if ($err) {
          //echo "cURL Error #:" . $err;            
            $arr = array('response' => 400);
            header('Content-Type: application/json');
            echo json_encode($arr);            
        } else {             
            $res = json_decode($response, true);                                   
            $requestStatus = $res['requestStatus'];
            $success = $requestStatus['success'];
            if($success == true){
                
                $booking = res['booking'];
                $orderNumber = $booking['orderNumber'];                
                $dataa['user_id']        = $this->input->post('user_id');            
                $dataa['date']        = $this->input->post('date');
                $dataa['time']        = $this->input->post('time');
                $dataa['promocode']        = $this->input->post('promocode');
                $dataa['ticket_count']        = $this->input->post('people');
                $dataa['tour_id']        =  $this->db->get_where('tour', array('product_code'=>$this->input->post('productCode')))->row()->id;                
                $dataa['state']        = '2';
                $dataa['code'] = $orderNumber;
                $this->db->insert('reservation', $dataa);
                $insert_id = $this->db->insert_id();                        
                
                $arr = array('response' => 200, 'booking'=>$booking, 'rsv_id'=>$insert_id);
                header('Content-Type: application/json');
                echo json_encode($arr);
            }else{
                 $arr = array('response' => 400);
                 header('Content-Type: application/json');
                 echo json_encode($arr);
            }               
        }
    }        
    

}
